const fs = require("fs");
const {
  Document, Packer, Paragraph, TextRun, HeadingLevel, AlignmentType,
  Table, TableRow, TableCell, WidthType, ShadingType, BorderStyle,
  ImageRun, SectionType, PageBreak, VerticalAlign, TabStopType, TabStopPosition,
  TableLayoutType
} = require("docx");

const FONT = "Times New Roman";

// ---------- helpers ----------
function run(text, opts = {}) {
  return new TextRun({ text, font: FONT, size: 20, ...opts }); // size 20 half-pt = 10pt body
}
function italicRun(text, opts = {}) {
  return run(text, { italics: true, ...opts });
}
function boldRun(text, opts = {}) {
  return run(text, { bold: true, ...opts });
}

function bodyPara(children, opts = {}) {
  return new Paragraph({
    children: Array.isArray(children) ? children : [children],
    spacing: { after: 120 },
    alignment: AlignmentType.JUSTIFIED,
    ...opts,
  });
}

function sectionHeading(text, numeral) {
  return new Paragraph({
    children: [boldRun(`${numeral}. ${text}`, { size: 21 })],
    spacing: { before: 240, after: 120 },
    alignment: AlignmentType.LEFT,
  });
}

function subHeading(letter, text) {
  return new Paragraph({
    children: [italicRun(`${letter}. ${text}`, { bold: true, size: 20 })],
    spacing: { before: 160, after: 80 },
  });
}

function figureImage(path, widthPx, heightPx, maxWidthIn = 3.35) {
  const aspect = heightPx / widthPx;
  const wIn = Math.min(maxWidthIn, widthPx / 300);
  const hIn = wIn * aspect;
  // Same distortion fix as eqImage: pass unrounded float pixel values so
  // docx's own fine-grained EMU-stage rounding preserves the true aspect
  // ratio, rather than pre-rounding to integer pixels ourselves.
  return new Paragraph({
    children: [
      new ImageRun({
        data: fs.readFileSync(path),
        transformation: { width: wIn * 96, height: hIn * 96 },
        type: "png",
      }),
    ],
    alignment: AlignmentType.CENTER,
    spacing: { before: 120, after: 60 },
  });
}

// All equation images are rendered at the SAME matplotlib fontsize and the
// SAME dpi (300), tightly cropped to their own bounding box. That means
// every PNG's true physical size (px / dpi) is already correctly
// proportioned relative to every other equation -- exactly as if they were
// all typeset at one consistent font size in LaTeX.
//
// FONT-SIZE FIX (3rd pass): the 2nd-pass fix anchored the scale on a target
// character size of 9.5pt, chosen only to guarantee nothing overflowed the
// column -- but never checked against what a normal, LEGIBLE inline-image
// size actually looks like in this paper series. 9.5pt is smaller than the
// 10pt body text itself, and some equations rendered as small as ~9pt tall
// on the actual page -- at typical viewing/printing resolution that is
// small enough to look badly compressed/illegible, which reads as
// "distorted" even though the pixel aspect ratio is mathematically exact.
//
// The correct reference is DGTAP's OWN inline images (measured directly
// from its docx XML): they range from 0.177in to 0.365in tall (12.7pt-
// 26.3pt), median 0.255in (~18.4pt). We now anchor DHT's single-line
// equations to that same ~18.4pt scale, so equations in this paper match
// the visual weight of DGTAP's own inline images rather than an arbitrary,
// too-small target picked only to avoid overflow.
const EQ_DPI = 300;
const EQ_TARGET_CHAR_PT = 18.4; // matches DGTAP's own median inline-image height
const EQ_MAX_WIDTH_IN = 2.9;   // hard cap so nothing can overflow the column
function computeGlobalEqScale(singleLineHeightsPx, widestWidthPx) {
  const refHeightPx = singleLineHeightsPx.reduce((a, b) => a + b, 0) / singleLineHeightsPx.length;
  let scale = (EQ_TARGET_CHAR_PT / 72 * EQ_DPI) / refHeightPx;
  // If the widest equation in the whole set would overflow the column at
  // this scale, shrink the scale globally (applied to every equation
  // equally) just enough that the widest one fits -- see rationale above
  // eqImage for why this must be a single shared adjustment, not a
  // per-equation cap.
  const widestWidthIn = (widestWidthPx / EQ_DPI) * scale;
  if (widestWidthIn > EQ_MAX_WIDTH_IN) {
    scale = EQ_MAX_WIDTH_IN / (widestWidthPx / EQ_DPI);
  }
  return scale;
}

function eqImage(path, widthPx, heightPx, label, globalScale) {
  const wIn = (widthPx / EQ_DPI) * globalScale;
  const hIn = (heightPx / EQ_DPI) * globalScale;
  // DISTORTION FIX: docx-js internally converts transformation.width/height
  // to EMU via Math.round(value * 9525) -- i.e. it does its own final
  // rounding at the EMU stage (9525 EMU per pixel, very fine-grained).
  // Passing already-integer-rounded pixel counts here was the actual bug:
  // at the small sizes used for equations (target heights of only ~12-24
  // pixels), rounding width and height to integers *before* handing them to
  // docx discards enough precision to visibly distort the aspect ratio (up
  // to ~3% in testing). Passing the exact, unrounded floating-point pixel
  // values instead lets docx's own EMU-level rounding preserve the true
  // aspect ratio to within ~0.0003%, which is visually exact.
  const wPx = wIn * 96;
  const hPx = hIn * 96;
  // LAYOUT FIX (the actual "squeezed into a clump" bug): equations were
  // previously wrapped in a Table (first with PERCENTAGE/autofit widths,
  // then with FIXED-layout DXA widths). Even with an explicit fixed layout,
  // a TABLE nested inside a multi-column SECTION is a known fragile
  // combination across Word/LibreOffice renderers -- the table can still
  // be recalculated/compressed against its (very small) image content in
  // some renderers, squeezing the equation into a cramped clump regardless
  // of what width the table or its columns were told to use.
  //
  // The robust fix is to remove the table wrapper entirely. A single
  // Paragraph containing an inline image run, followed by a tab character
  // and a right-aligned equation-number run (using a right tab stop at the
  // column's right margin) achieves the same visual layout -- image on the
  // left, "(n)" flush right -- without any table involved. There is
  // nothing for a renderer to "autofit" or collapse: the image's
  // transformation width/height is the only sizing information, so it
  // renders at exactly the size requested.
  const colWidthDxa = 4680; // matches the data-table width used elsewhere (one column)
  return new Paragraph({
    tabStops: [{ type: TabStopType.RIGHT, position: colWidthDxa }],
    children: [
      new ImageRun({
        data: fs.readFileSync(path),
        transformation: { width: wPx, height: hPx },
        type: "png",
      }),
      new TextRun({ text: "\t" }),
      run(`(${label})`, { size: 20 }),
    ],
    spacing: { before: 80, after: 80 },
  });
}


function figCaption(text) {
  return new Paragraph({
    children: [run(text, { size: 18 })],
    alignment: AlignmentType.CENTER,
    spacing: { after: 200 },
  });
}

function makeTable(headerCells, rows, colWidths) {
  const totalWidth = 4680; // ~3.25in in DXA at column width, matches 2-col layout
  const widths = colWidths || headerCells.map(() => Math.floor(totalWidth / headerCells.length));
  const headerRow = new TableRow({
    tableHeader: true,
    cantSplit: true,
    children: headerCells.map((h, i) => new TableCell({
      width: { size: widths[i], type: WidthType.DXA },
      shading: { type: ShadingType.CLEAR, fill: "D9D9D9" },
      children: [new Paragraph({
        children: [boldRun(h, { size: 16 })],
        alignment: AlignmentType.CENTER,
      })],
    })),
  });
  const bodyRows = rows.map(r => new TableRow({
    cantSplit: true,
    children: r.map((cellText, i) => new TableCell({
      width: { size: widths[i], type: WidthType.DXA },
      children: [new Paragraph({
        children: [run(String(cellText), { size: 16 })],
        alignment: i === 0 ? AlignmentType.LEFT : AlignmentType.CENTER,
      })],
    })),
  }));
  return new Table({
    width: { size: totalWidth, type: WidthType.DXA },
    columnWidths: widths,
    rows: [headerRow, ...bodyRows],
  });
}

function tableCaption(label, text) {
  return new Paragraph({
    children: [run(`${label}`, { smallCaps: true, size: 16 }), run(`\n${text}`, { size: 16 })],
    alignment: AlignmentType.CENTER,
    spacing: { before: 160, after: 80 },
    keepNext: true,
  });
}

function refPara(text) {
  return new Paragraph({
    children: [run(text, { size: 18 })],
    spacing: { after: 100 },
    alignment: AlignmentType.JUSTIFIED,
  });
}

const M = "paper_media/";

// Global scale factor applied to every equation image, anchored on the
// median height of the paper's single-line equations (Eq. 2, 3, 4, 5, 7)
// so that ordinary single-line equations render at a comfortable,
// consistent character size matching DGTAP's own inline-image scale
// (~18.4pt). Fraction/nested equations (Eq. 1, 6, 8, 9, 10) are then
// allowed to be taller in direct proportion to their genuine extra
// content, exactly as they would be in properly typeset LaTeX -- see
// comment above eqImage. The widest equation's width (Eq. 7) is passed in
// so the function can shrink the whole set uniformly if needed to keep
// Eq. 7 inside the column -- see comment above computeGlobalEqScale for
// why this must be a single shared adjustment.
//
// PADDING FIX: all equation source images were re-rendered with a fixed
// vertical-alignment bug corrected (see eqs_final generation script) --
// previously every equation had exactly 0px of padding below its lowest
// descender (e.g. the "p" in a "spot" subscript), because matplotlib
// anchors text by baseline, not bounding box, when placed with fig.text().
// Any subsequent rounding or tight layout could then clip that descender
// completely, which is what produced equations that looked "squeezed" or
// unreadable. All 10 equations now have 16-34px of genuine padding on
// every side; the dimensions below reflect the new, correctly-padded PNGs.
const EQ_SCALE = computeGlobalEqScale([
  124, // eq2 (single-line)
  134, // eq3 (single-line)
  134, // eq4 (single-line)
  134, // eq5 (single-line)
  134, // eq7 (single-line)
], 2202); // eq7 is the widest equation in the paper

// ============================================================
// TITLE BLOCK (single column)
// ============================================================
const titleBlock = [
  new Paragraph({
    children: [boldRun(
      "Dynamic Hedge-grid Trading Strategy: Layering a Reverse Perpetual-Futures Hedge into Dynamic Grid Trading's Recycle Mechanism",
      { size: 32 }
    )],
    alignment: AlignmentType.CENTER,
    spacing: { after: 200 },
  }),
  new Paragraph({
    children: [italicRun("[Author name(s) to be filled in]", { size: 22, italics: false })],
    alignment: AlignmentType.CENTER,
    spacing: { after: 40 },
  }),
  new Paragraph({
    children: [italicRun("[Affiliation to be filled in]", { size: 22 })],
    alignment: AlignmentType.CENTER,
    spacing: { after: 40 },
  }),
  new Paragraph({
    children: [run("July 2026", { size: 22 })],
    alignment: AlignmentType.CENTER,
    spacing: { after: 200 },
  }),

  new Paragraph({
    children: [
      italicRun("Note on provenance: ", { bold: true, size: 20 }),
      italicRun(
        "This paper builds on Dynamic Grid Trading (\u201cDGT\u201d), introduced by Chen, Chen, and Jang [1], and on our own prior extension, Dynamic Grid Trading with Anti-Martingale Sizing and Protective Options (\u201cDGTAP\u201d) [2]. DGT's reset mechanism and zero-expectation proof are cited, not reproduced, from [1]. The extension proposed here \u2014 replacing DGTAP's anti-martingale throttle and protective-put overlay with a reverse perpetual-futures hedge layered into DGT's down-break recycle event, jointly named Dynamic Hedge-grid Trading (DHT) \u2014 together with all backtest results in Section V, is original to this paper and was produced independently on real market data as described in Section IV.",
        { size: 20 }
      ),
    ],
    spacing: { after: 160 },
    alignment: AlignmentType.JUSTIFIED,
  }),

  new Paragraph({
    children: [
      italicRun("Abstract\u2014", { bold: true, size: 20 }),
      italicRun(
        "Dynamic Grid Trading (DGT) [1] breaks the classical grid strategy's zero-expectation property by fully liquidating to cash or fully deploying to inventory whenever price exits the trading band, then re-centering a fresh grid on the breach price. This down-break \u201crecycle\u201d rule is also DGT's chief residual risk: it concentrates buying activity during sustained downtrends. Our earlier work, DGTAP [2], addressed this with a consecutive-fill position throttle and an options-based tail hedge. Here we propose a structurally different extension \u2014 Dynamic Hedge-grid Trading (DHT) \u2014 which, instead of throttling position size, layers a reverse (short) perpetual-futures hedge directly into each down-break recycle event. On every recycle, DHT (i) deploys the recycle's first spot layer as in vanilla DGT, (ii) recomputes a short-perpetual hedge sized at a fixed fraction (hedge_ratio) of the *entire* net spot position accumulated since the current \u201cbig cycle\u201d began, and (iii) widens grid spacing by a fixed increment (stepCycleAdd) once per recycle. The big cycle exits and restarts when combined spot-plus-hedge equity, net of funding, returns to its starting value. On 3.5 years of real minute-resolution BTC/USD data (Bitstamp, January 2021 to July 2024), under a reset-count-constrained search analogous to that used for DGTAP, an operating point of hedge_ratio\u202f=\u202f0.6, stepCycleAdd\u202f=\u202f0.005, and an assumed +10%/year funding carry (favorable to DHT's short hedge, per standard perpetual-funding convention) improves the Calmar ratio from DGT's 0.436 to 1.294, simultaneously raising IRR (20.20%\u219229.74%) and roughly halving maximum drawdown (\u221246.29%\u2192\u221222.99%). We report two methodological pitfalls discovered during development \u2014 a specification ambiguity in the global profit-exit condition that caused spurious restarts before any hedge ever engaged, and an unmargined mark-to-market model that produced impossible negative-equity paths at some parameter settings \u2014 and the fixes adopted for each. We further show the headline result is sensitive to both the assumed funding rate (a regime shift occurs near +7\u20138%/year, below which DHT is no better than DGT) and to bar-sampling frequency (the 1-minute-tuned operating point does not transfer cleanly to hourly bars), and report both sensitivities explicitly rather than a single point estimate.",
        { size: 20 }
      ),
    ],
    spacing: { after: 160 },
    alignment: AlignmentType.JUSTIFIED,
  }),

  new Paragraph({
    children: [
      italicRun("Index Terms\u2014", { bold: true, size: 20 }),
      italicRun("algorithmic trading, grid trading, cryptocurrency, perpetual futures, funding rate, hedging, tail risk, backtest overfitting, Bitcoin.", { size: 20 }),
    ],
    spacing: { after: 120 },
  }),
];

// ============================================================
// SECTION I. INTRODUCTION
// ============================================================
const sectionI = [
  sectionHeading("INTRODUCTION", "I"),
  bodyPara([
    run("This paper builds on Dynamic Grid Trading (DGT), the reset-based grid strategy proposed by Chen, Chen, and Jang [1], and on our own prior extension, DGTAP [2], which we summarize briefly here for self-containedness. Grid trading lays down "),
    italicRun("n"),
    run(" equally or geometrically spaced price levels around a reference price and mechanically sells inventory as price rises through a level, buying back as it falls through one. Under a symmetric random-walk assumption, this classical rule has zero expected profit before fees [1]. DGT breaks this result with a single structural change: rather than stopping when price exits the trading band, the strategy fully liquidates (upper breach) or fully deploys capital (lower breach), then re-centers a fresh grid on the breach price and continues. This recycling of capital at the boundary is what generates DGT's realized edge, and it is also the mechanism responsible for its chief residual risk: sustained downtrends drive repeated lower-boundary breaches, each of which commits more capital to a falling asset before any recovery."),
  ]),
  bodyPara([
    run("In DGTAP [2] we addressed this residual risk with two additions running in parallel with the grid: a consecutive-fill anti-martingale position throttle that shrinks buy-side sizing during sustained down-runs, and a periodically rolled out-of-the-money protective put funded from a small fixed fraction of the wallet. The throttle produced a robust, assumption-free improvement (Calmar 0.436\u21920.538); the put overlay's marginal value was shown to depend heavily on an unobservable implied-to-realized volatility ratio, ranging from roughly breakeven to a near-doubling of the Calmar ratio depending on that assumption."),
  ]),
  bodyPara([
    run("This paper explores a structurally different extension. Rather than throttling the size of spot buys, or purchasing a decaying option position, Dynamic Hedge-grid Trading (DHT) attaches a "),
    italicRun("reverse perpetual-futures hedge"),
    run(" directly to DGT's own down-break recycle event. Perpetual futures are now the dominant instrument for taking short cryptocurrency exposure on major exchanges, trade with deep liquidity and continuous funding-rate price discovery, and do not decay with time the way an option position does \u2014 a structurally different risk-transfer mechanism from DGTAP's put overlay, motivating a separate evaluation rather than a parametric variant of the same idea."),
  ]),
  bodyPara([
    run("Every time DGT's lower boundary is breached, DHT (i) deploys the recycle's first spot layer exactly as vanilla DGT does, (ii) recomputes a short-perpetual hedge sized at a fixed fraction, hedge_ratio, of the "),
    italicRun("entire"),
    run(" net spot position accumulated since the current \u201cbig cycle\u201d began \u2014 not just the newly added layer \u2014 and (iii) widens the grid's spacing by a fixed increment, stepCycleAdd, once per recycle, so that successive recycles within the same adverse run space their re-entries further apart. The big cycle \u2014 potentially spanning many recycles \u2014 exits and restarts once combined spot-plus-hedge equity, net of funding, returns to its starting value. This paper specifies the mechanism precisely (Section III), documents two methodological pitfalls encountered while implementing it (Section V-A\u2013V-B, in the same spirit as the pitfalls DGTAP documented for its own overlay), and reports backtest results together with their sensitivity to the funding-rate assumption and to bar-sampling frequency (Section V-E\u2013V-F), consistent with this paper series' standing practice of reporting genuine modeling uncertainty explicitly rather than collapsing it into a single number."),
  ]),
];

// ============================================================
// SECTION II. RELATED WORK
// ============================================================
const sectionII = [
  sectionHeading("RELATED WORK", "II"),
  bodyPara([
    run("Grid trading and its zero-expectation baseline, DGT's boundary-reset mechanism, and DGTAP's anti-martingale throttle and protective-put overlay are reviewed in detail in [1] and [2] respectively, and are not repeated here. This section instead focuses on the literature specific to DHT's new mechanism: perpetual futures, funding rates, and delta hedging with futures instruments."),
  ]),
  subHeading("A", "Perpetual Futures and Funding Rates"),
  bodyPara([
    run("Perpetual futures contracts, introduced to cryptocurrency markets by BitMEX and now the dominant derivative instrument by traded volume on most major exchanges, have no expiry date; instead, a periodic funding payment exchanged directly between long and short position holders anchors the contract's price to the underlying spot index [3]. When the perpetual trades above spot, longs pay shorts (positive funding); when it trades below spot, shorts pay longs (negative funding). Empirical studies of realized funding-rate distributions on Bitcoin and Ethereum perpetuals document that funding is usually, but not always, positive over multi-year samples, with substantial regime-dependent variation and occasional sustained negative stretches during sharp downturns or after crowded long positioning unwinds [4], [5]. This asymmetry \u2014 a short hedge is a net receiver of funding when the market convention of predominantly positive funding holds, but a net payer during negative-funding regimes \u2014 is central to the sensitivity analysis in Section V-E."),
  ]),
  subHeading("B", "Futures-Based Delta Hedging"),
  bodyPara([
    run("Hedging a spot or physical position with an offsetting futures position is a classical risk-management technique predating cryptocurrency markets by decades [6], and minimum-variance hedge-ratio estimation \u2014 choosing the hedge size that minimizes the variance of the combined position \u2014 is a well-studied problem in commodities and financial futures [7]. DHT's hedge_ratio parameter is a simplified, fixed-fraction analogue of this minimum-variance hedge ratio, applied without a formal variance-minimization estimation step; Section VII lists a formally estimated minimum-variance hedge ratio as a specific direction for future refinement. Unlike a continuously rebalanced minimum-variance hedge, DHT's hedge is only resized at discrete recycle events, an intentional design choice paralleling DGT's own discrete (rather than continuous) rebalancing at grid boundaries."),
  ]),
  subHeading("C", "Margin and Liquidation Mechanics"),
  bodyPara([
    run("Leveraged perpetual positions are subject to maintenance-margin requirements and automatic liquidation once losses exceed posted margin; the mechanics of cross-margin and isolated-margin liquidation engines, including insurance funds and auto-deleveraging, are documented in exchange technical literature and studied empirically for their contribution to cascading liquidation events during volatile periods [8]. Section V-B documents a pitfall in an early version of the DHT backtest that omitted any margin constraint on the hedge leg, and the simplified liquidation cap adopted to correct it."),
  ]),
  subHeading("D", "Backtest Overfitting and Risk-Adjusted Performance Metrics"),
  bodyPara([
    run("As in [2], we rely throughout on the Calmar ratio and on the backtest-overfitting literature's caution against unconstrained parameter optimization over a single historical path [9], [10]. DGTAP documented two related pitfalls \u2014 resampling bias in grid-parameter search, and unconstrained optimization degenerating to zero-trade regimes \u2014 and applied a reset-count floor as a heuristic guard. Section V of this paper applies the analogous guard to DHT's hedge_ratio/stepCycleAdd parameter surface and documents a related, but distinct, third pitfall: an unconstrained search over that surface is highly non-monotonic even after a reset-count floor is applied, in a way DGTAP's smoother grid-size surface was not."),
  ]),
];

// ============================================================
// SECTION III. DHT: PROPOSED MECHANISM (with equations)
// ============================================================
const sectionIII = [
  sectionHeading("DHT: PROPOSED MECHANISM", "III"),
  subHeading("A", "Review of the DGT Recycle Event"),
  bodyPara([
    run("We restate DGT's boundary rule at the level needed to define DHT; see [1] for the full derivation and [2, Sec. III-A] for our earlier restatement. A geometric grid is defined by a center price "),
    italicRun("P"), run("\u2080, per-level ratio "), italicRun("k"), run(", and half-width "), italicRun("m"), run(", producing "), italicRun("2m+1"),
    run(" levels. On breaching the upper boundary "), italicRun("P"), run("\u2080(1+"), italicRun("k"), run(")"), italicRun("\u1d50"),
    run(" the strategy fully converts to cash; on breaching the lower boundary "), italicRun("P"), run("\u2080(1+"), italicRun("k"), run(")"), italicRun("\u207b\u1d50"),
    run(", it fully converts to inventory. A fresh grid is then re-centered on the breach price. DHT modifies only the "),
    italicRun("lower-boundary"),
    run(" (buy-the-dip direction) branch of this rule; upper-boundary breaches are handled exactly as in vanilla DGT and do not trigger any hedge activity or grid widening, per the design decision that DHT's risk-management mechanism should activate specifically on the down-side accumulation events DGT's own architecture concentrates risk into."),
  ]),
  subHeading("B", "The DHT Recycle Event"),
  bodyPara([
    run("We term each lower-boundary breach within a DHT "), italicRun("big cycle"), run(" a "), italicRun("recycle"),
    run(". A big cycle begins with starting equity "), italicRun("E"), run("\u2080 (all cash) and a freshly centered grid at base spacing "), italicRun("k"),
    run("\u2090\u2090\u2090\u2090. On the "), italicRun("r"), run("-th recycle within the current big cycle:"),
  ]),
  bodyPara([
    run("1) All remaining cash is deployed into spot at the breach price, exactly as vanilla DGT's lower-boundary rule (the recycle's \u201cfirst layer\u201d)."),
  ]),
  bodyPara([
    run("2) The hedge is fully recomputed \u2014 not incrementally adjusted \u2014 against the entire net spot quantity held since the big cycle began:"),
  ]),
  eqImage(M + "eq1_hedge_qty.png", 1493, 159, "1", EQ_SCALE),
  bodyPara([
    run("where hedge_ratio\u2009\u2208\u2009[0,1] is a fixed configuration parameter (Section V reports a search over this parameter, including the hedge_ratio\u2009=\u20090 no-hedge case as a control). Any previously open hedge is closed \u2014 its price P&L settled into the spot wallet \u2014 and a new short position of size "),
    italicRun("Q"), run("\u2095\u2091\u2091\u2091\u2091 is opened at the breach price. Recomputing against the full accumulated position, rather than hedging only the newly added layer, means the hedge tracks the "),
    italicRun("cumulative"), run(" drawdown-driven inventory build-up directly, at the cost of requiring the entire hedge to be closed and reopened (incurring re-entry basis) at every recycle."),
  ]),
  bodyPara([
    run("3) Grid spacing widens by a fixed increment, stepCycleAdd, once per recycle:"),
  ]),
  eqImage(M + "eq2_widening.png", 1666, 124, "2", EQ_SCALE),
  bodyPara([
    run("so that successive recycles within a sustained down-run space their re-entry levels progressively further apart, reducing the frequency of new capital commitment as an adverse run continues \u2014 a different risk-reduction mechanism from DGTAP's throttle (which shrinks the "),
    italicRun("fraction"), run(" of cash committed per fill) but a related design intent: both mechanisms de-risk the "),
    italicRun("n"), run("-th consecutive same-direction event relative to the first."),
  ]),
  bodyPara([
    run("4) Buy-side sizing on the new, wider grid restarts at the grid's ordinary first-layer fraction; DHT does not carry over a consecutive-fill throttle, since the hedge is the mechanism assigned to the de-risking role in this design."),
  ]),
  subHeading("C", "Funding Accrual and Hedge Mark-to-Market"),
  bodyPara([
    run("Funding is accrued every bar against the currently open hedge notional, using a constant assumed annualized rate "), italicRun("f"), run("\u2090\u209a\u1d63:"),
  ]),
  eqImage(M + "eq3_funding.png", 1435, 134, "3", EQ_SCALE),
  bodyPara([
    run("Because DHT's hedge is short, a positive "), italicRun("f"), run("\u2090\u209a\u1d63 (the historically typical sign, per Section II-A) is a tailwind: the hedge collects funding, consistent with the standard convention that positive funding is paid by longs to shorts. The hedge's unrealized price P&L is marked each bar as:"),
  ]),
  eqImage(M + "eq4_hedge_pnl.png", 1563, 134, "4", EQ_SCALE),
  bodyPara([
    run("and combined mark-to-market equity, used for both the reported equity curve and the big-cycle exit test, is:"),
  ]),
  eqImage(M + "eq5_combined_equity.png", 1646, 134, "5", EQ_SCALE),
  subHeading("D", "Global Profit-Exit Condition"),
  bodyPara([
    run("A big cycle ends \u2014 all positions flattened, a new grid centered, stepCycleAdd reset to zero \u2014 the first time combined equity closes back at or above the big cycle's starting equity, "), italicRun("and"),
    run(" at least one recycle has occurred in the current big cycle (Section V-A explains why this second condition is necessary):"),
  ]),
  eqImage(M + "eq6_exit_condition.png", 1640, 162, "6", EQ_SCALE),
  subHeading("E", "Hedge Margin and Forced Liquidation"),
  bodyPara([
    run("A real short-perpetual position is posted with margin and is force-liquidated by the exchange once losses exceed that margin; it cannot draw down the rest of the portfolio to an arbitrary negative value the way an unmargined mark-to-market claim can in a naive simulation (Section V-B documents the failure mode this guards against). We cap each hedge leg's tolerated loss at a fixed fraction of its opening notional:"),
  ]),
  eqImage(M + "eq7_liquidation.png", 2202, 134, "7", EQ_SCALE),
  bodyPara([
    run("with margin_frac\u2009=\u20090.5 throughout this paper. Once breached, the hedge is force-closed at that loss level, booked into the wallet, rather than allowed to run further. This is a simplification of real cross/isolated margin mechanics (which also involve partial liquidations, insurance funds, and liquidation-price slippage), adopted specifically to prevent the backtest from reporting equity paths no real exchange position could produce."),
  ]),
  subHeading("F", "Combined Algorithm and Evaluation Metrics"),
  bodyPara([
    run("DHT is DGT with the lower-boundary branch extended by steps (1)\u2013(3) of Section III-B and a parallel short-perpetual hedge managed per Sections III-C\u2013III-E; the upper-boundary (take-profit) branch is unmodified vanilla DGT. As in [1] and [2], performance is summarized with annualized IRR, maximum drawdown (MDD), and the Calmar ratio:"),
  ]),
  eqImage(M + "eq8_irr.png", 906, 191, "8", EQ_SCALE),
  eqImage(M + "eq9_mdd.png", 1189, 269, "9", EQ_SCALE),
  eqImage(M + "eq10_calmar.png", 761, 182, "10", EQ_SCALE),
  bodyPara([
    run("where "), italicRun("V"), run("\u2080 and "), italicRun("V"), run("\u1d40 are initial and final combined equity, "), italicRun("T"), run("\u1d67\u1d63 is the sample length in years, and "), italicRun("V"), run("\u209c is the mark-to-market combined equity curve of Eq. 5."),
  ]),
  new Paragraph({ children: [], spacing: { after: 40 } }),
  tableCaption("TABLE I", "Summary of Symbols Used in Section III"),
  makeTable(
    ["Symbol", "Meaning"],
    [
      ["P\u2080, k, m", "Grid center price, level ratio, half-width"],
      ["r, stepCycleAdd", "Recycle count; per-recycle spacing increment"],
      ["hedge_ratio, Q hedge, Q spot", "Hedge fraction; short-hedge and net spot qty"],
      ["f_apr, \u0394t, \u03a0 hedge(P_t)", "Funding rate; bar duration; hedge P&L"],
      ["E_t, E\u2080, margin_frac", "Combined/starting equity; margin cap"],
      ["V_t, IRR, MDD", "Equity curve; annualized return; drawdown"],
    ],
    [1900, 2780]
  ),
];

// ============================================================
// SECTION IV. DATA
// ============================================================
const sectionIV = [
  sectionHeading("DATA AND EXPERIMENTAL SETUP", "IV"),
  bodyPara([
    run("All results use real, exchange-sourced data: Bitstamp BTC/USD, one-minute resolution, January 1, 2021 through July 31, 2024 (1,882,081 bars), the same dataset and window used in [2] and matching the evaluation window of [1]. A round-trip taker fee of 8 bps (0.0008) is applied to every grid fill, and initial capital is normalized to 100 units for all reported figures, consistent with [2]. The hedge leg carries no separate exchange fee or bid-ask spread beyond the funding accrual of Eq. 3 (Section VI-C)."),
  ]),
  bodyPara([
    run("As in [2], we did not obtain comparable real minute-resolution ETH data within the constraints of this study; all results are BTC-only, a limitation carried over from and discussed further in Section VI."),
  ]),
];

// ============================================================
// SECTION V. RESULTS
// ============================================================
const sectionV = [
  sectionHeading("RESULTS", "V"),
  subHeading("A", "Pitfall 1: A Degenerate Global Profit-Exit"),
  bodyPara([
    run("An initial implementation checked the global profit-exit condition (Eq. 6, without the recycle-count guard) on every bar. Because ordinary DGT-style grid trading is close to zero-expectation before a genuine drawdown occurs, combined equity returns to its starting value on almost any bar where the grid sits near its center with a small residual position \u2014 with no recycle and no hedge ever having occurred. In a diagnostic run over the first 5,000 bars of the sample, this fired over 100 spurious restarts before a single recycle event ever triggered, meaning DHT's hedge mechanism would never actually engage in a naive implementation of the literal exit rule. We resolved this by gating the exit check on "),
    italicRun("r"), run(" > 0 (Eq. 6): the global exit is only evaluated once at least one down-side recycle \u2014 and therefore a live hedge \u2014 has occurred in the current big cycle. This is reported explicitly as a specification refinement rather than silently patched, consistent with this paper series' practice of surfacing ambiguities rather than hiding them."),
  ]),
  subHeading("B", "Pitfall 2: Unmargined Hedge Produces Impossible Negative Equity"),
  bodyPara([
    run("Sensitivity testing of hedge_ratio and stepCycleAdd surfaced parameter combinations (e.g., hedge_ratio\u2009=\u20090.7, stepCycleAdd\u2009=\u20090.02) that produced negative final equity from a $100 start. The root cause: a hedge opened deep in a drawdown remains open, unresized, until the "),
    italicRun("next"), run(" recycle; if price then rallies substantially before another lower-boundary breach occurs \u2014 as BTC did into its March 2024 all-time high after a hedge entered near a much lower 2022 low \u2014 the hedge's unrealized loss, marked without any margin limit, can exceed the entire starting portfolio value many times over. This is not how a real perpetual short behaves: an exchange would force-liquidate the position once losses exceeded posted margin, long before the loss could draw down the rest of the wallet. We therefore adopted the liquidation cap of Eq. 7 (margin_frac\u2009=\u20090.5); with it in place, all parameter combinations tested in Section V-C produce bounded, realistic drawdowns and no negative-equity paths."),
  ]),
  subHeading("C", "Reset-Constrained Parameter Search"),
  bodyPara([
    run("Mirroring [2]'s reset-count floor (applied there to guard against grid configurations with too few reset events to be statistically meaningful), we searched hedge_ratio\u2009\u2208\u2009{0.0,\u20090.1,\u2026,\u20091.0} and stepCycleAdd\u2009\u2208\u2009{0,\u20090.0025,\u20090.005,\u2026,\u20090.03} at fixed grid parameters (k\u2009=\u20092.5%, m\u2009=\u20096, the same operating point identified as Calmar-optimal for vanilla DGT in [2, Table V]), retaining only configurations with at least 15 recycle events over the 3.5-year sample (71 of 88 cells)."),
  ]),
  figureImage(M + "fig1_dht_heatmap.png", 1240, 860),
  figCaption("Fig. 1. Calmar ratio across hedge_ratio and stepCycleAdd, recycle-count \u2265 15 guard, native 1-minute BTC data. The surface is non-monotonic: adjacent cells at the same hedge_ratio frequently swing between strongly positive and near-zero or negative Calmar."),
  bodyPara([
    run("Unlike DGTAP's grid-size/half-width surface, which varied smoothly [2, Fig. 1], the hedge_ratio/stepCycleAdd surface is highly non-monotonic even after the reset-count floor (Fig. 1): the single best cell, hedge_ratio\u2009=\u20090.6, stepCycleAdd\u2009=\u20090.005 (Calmar 1.294), sits adjacent to cells at the same hedge_ratio scoring below 0.1. We treat this as a third, distinct pitfall worth reporting alongside Sections V-A\u2013V-B: unlike DGT's grid-size dimension, DHT's hedge/widening interaction does not appear to have a broad, smoothly-varying optimum, and a single reported \u201cbest\u201d cell is correspondingly less robust as a recommendation. A robustness check \u2014 median Calmar across each hedge_ratio's non-zero-stepCycleAdd neighbors \u2014 does show hedge_ratio\u2009\u2208\u2009[0.5,\u20090.9] as a broadly favorable band (median Calmar 0.35\u20130.64) relative to the extremes (hedge_ratio\u2009=\u20090.0 or 1.0, median Calmar approx. 0.16\u20130.23), which is the basis for adopting hedge_ratio\u2009=\u20090.6 below rather than treating it as an isolated lucky cell."),
  ]),
  figureImage(M + "fig2_dht_widening_schedule.png", 1240, 800),
  figCaption("Fig. 2. Grid-spacing widening schedule at the adopted stepCycleAdd = 0.005: spacing grows modestly and linearly with recycle count within a big cycle."),
  subHeading("D", "Headline Operating Point"),
  tableCaption("TABLE II", "Grid 2.5%/m=6, hedge_ratio=0.6, stepCycleAdd=0.005, funding=+10%/yr"),
  makeTable(
    ["Strategy", "IRR", "MDD", "Calmar"],
    [
      ["Buy & Hold", "25.93%", "\u221277.54%", "0.334"],
      ["DGT (baseline of [1])", "20.20%", "\u221246.29%", "0.436"],
      ["DHT (this paper)", "29.74%", "\u221222.99%", "1.294"],
    ],
    [1900, 900, 900, 900]
  ),
  figureImage(M + "fig3_dht_equity_curves.png", 1300, 800),
  figCaption("Fig. 3. Mark-to-market equity curves, daily-resampled, BTC/USD, Jan 2021\u2013Jul 2024. DHT tracks DGT closely through 2021\u2013early 2022, then visibly avoids DGT's deepest 2022 drawdown while continuing to compound through the 2023\u201324 recovery."),
  bodyPara([
    run("At this operating point, DHT both out-returns buy-and-hold (29.74% vs. 25.93% IRR) and nearly halves DGT's drawdown (\u221223.0% vs. \u221246.3%), roughly tripling the Calmar ratio relative to the DGT baseline. Twenty-five recycle events occurred across sixteen completed big cycles over the sample; no hedge liquidations were triggered at this operating point."),
  ]),
  subHeading("E", "Sensitivity to the Funding-Rate Assumption"),
  bodyPara([
    run("As in [2]'s treatment of the put overlay's volatility-ratio assumption, we did not treat the assumed funding rate as a fixed, unquestioned input. Fig. 4 sweeps the assumed annualized funding rate at the fixed operating point of Table II."),
  ]),
  figureImage(M + "fig4_dht_funding_sensitivity.png", 1240, 800),
  figCaption("Fig. 4. Calmar ratio as a function of the assumed annualized funding rate, hedge_ratio=0.6, stepCycleAdd=0.005. A regime shift occurs near +7\u20138%/year; below this, DHT is comparable to or worse than the DGT baseline (dotted line)."),
  bodyPara([
    run("The result is materially assumption-dependent: DHT's Calmar advantage over DGT is concentrated in a funding-rate regime at or above roughly +7\u20138%/year, consistent with historically typical but not universal positive-funding conditions documented in [4], [5]. Below this threshold \u2014 including the zero-funding and negative-funding cases that do occur during real market stress \u2014 DHT's Calmar ratio falls to 0.00\u20130.45, at or below the unhedged DGT baseline (0.436). We adopt +10%/year as the paper's headline assumption because it sits within, rather than at the edge of, historically documented typical ranges [4], [5], but we report Fig. 4 in full rather than only the favorable point estimate, and regard funding-rate risk as DHT's single most consequential open assumption, directly analogous to DGTAP's unresolved implied/realized volatility ratio for its put overlay."),
  ]),
  subHeading("F", "Robustness to Bar-Sampling Frequency"),
  bodyPara([
    run("As an independent check \u2014 same asset, same window, only the bar frequency changes \u2014 we re-ran the Table II operating point on hourly-resampled BTC/USD bars from the same source (31,369 bars). The result did not transfer cleanly: DHT's Calmar ratio fell to 0.178, versus DGT's own hourly-bar Calmar of 0.175 \u2014 effectively a wash, not the clear improvement seen on native 1-minute bars. A full hourly re-sweep of hedge_ratio and stepCycleAdd shows good cells still exist at hourly resolution (e.g., hedge_ratio\u2009=\u20090.7, stepCycleAdd\u2009=\u20090.02 reaches Calmar 1.072), but they are different cells from the 1-minute optimum, and the hourly surface is at least as non-monotonic as the 1-minute one. We read this as an overfitting warning rather than a mechanism failure: the qualitative claim that hedged recycling can beat plain DGT still holds at hourly resolution given a re-tuned operating point, but the specific parameter values reported in Table II are tied to the 1-minute sampling frequency used to find them and should not be assumed to transfer to a different execution or rebalancing cadence."),
  ]),
  tableCaption("TABLE III", "Ranges Tested in Section V"),
  makeTable(
    ["Parameter", "Range tested", "Selected"],
    [
      ["Grid size k (7 discrete values)", "1.0% \u2013 5.0%", "2.5%"],
      ["Half-width m", "4 \u2013 8", "6"],
      ["hedge_ratio", "0.0 \u2013 1.0", "0.6"],
      ["stepCycleAdd", "0 \u2013 0.03", "0.005"],
      ["Funding rate (annualized)", "\u221210% \u2013 +15%", "+10% (headline)"],
    ],
    [2500, 1250, 950]
  ),
  bodyPara([
    run("Grid size and half-width were not re-optimized for DHT specifically; the row above reports the discrete 7\u00d75 grid re-checked on native 1-minute vs. hourly bars (Section V-F) using the vanilla-DGT code path, confirming k\u2009=\u20092.5%, m\u2009=\u20096 \u2014 the operating point identified as Calmar-optimal for DGT in [2, Table V] \u2014 remains reasonable before layering DHT's hedge on top. The margin liquidation cap (Eq. 7) was fixed at 50% of notional throughout and was not itself swept.", { size: 18 }),
  ]),
];

// ============================================================
// SECTION VI. DISCUSSION AND LIMITATIONS
// ============================================================
const sectionVI = [
  sectionHeading("DISCUSSION AND LIMITATIONS", "VI"),
  subHeading("A", "Single-Asset, Single-Window Evaluation"),
  bodyPara([
    run("As in [2], all results use BTC/USD only, over one historical period. ETH data comparable in resolution was not available within the constraints of this study; we regard ETH validation, and validation across multiple non-overlapping historical windows, as a prerequisite before the reported hedge_ratio/stepCycleAdd values should be treated as settled recommendations, particularly given the volatility-clustering and asymmetry differences documented between BTC and ETH even within a common GARCH-family framework [2, Sec. VI]."),
  ]),
  subHeading("B", "Funding-Rate Risk Is the Central Open Assumption"),
  bodyPara([
    run("Section V-E shows DHT's headline result depends on a funding-rate regime that has historically been common but is neither universal nor guaranteed to persist [4], [5]. A production deployment would need to either accept this as a real, priced risk \u2014 the same way any short-carry strategy accepts funding/borrow-rate risk \u2014 or dynamically size or pause the hedge based on realized/forecast funding, which this paper does not attempt. We regard this as directly analogous to, and no more resolved than, DGTAP's open implied/realized volatility ratio assumption for its put overlay [2, Sec. V-D, VI]."),
  ]),
  subHeading("C", "Simplified Margin and Execution Model"),
  bodyPara([
    run("The 50%-of-notional liquidation cap (Eq. 7) is a coarse stand-in for real cross/isolated margin and mark-price mechanics, which additionally include partial liquidations, insurance funds, and liquidation-price slippage documented in exchange-level empirical studies [8]. No spread, slippage, or separate exchange fee is modeled on the hedge leg beyond funding and price P&L. Both simplifications bias the reported results in DHT's favor and should be tightened before any live deployment."),
  ]),
  subHeading("D", "Overfitting Risk in Hedge-Parameter Selection"),
  bodyPara([
    run("Section V-C documents that DHT's hedge_ratio/stepCycleAdd surface is considerably less smooth than DGT's own grid-size surface, even after an analogous reset-count floor. Reporting a single \u201cbest\u201d cell (Table II) understates this instability more than the equivalent choice did for DGTAP's grid parameters; the neighborhood-median robustness check of Section V-C is a heuristic partial mitigation, not a resolution, and a fuller treatment would apply the length-normalized, resampling-based corrections used in the broader backtest-overfitting literature [9], [10]."),
  ]),
  subHeading("E", "Relationship to DGTAP's Throttle-and-Put Approach"),
  bodyPara([
    run("DHT and DGTAP address the same underlying concern \u2014 DGT's tendency to concentrate risk during sustained downtrends \u2014 through structurally different mechanisms: DGTAP shrinks the "),
    italicRun("size"), run(" of each buy and separately purchases decaying convex protection; DHT instead attaches a non-decaying, continuously mark-to-market short position sized against the "), italicRun("cumulative"),
    run(" spot build-up. The two approaches are not mutually exclusive: a natural direction for future work is a combined DGT+throttle+hedge variant, evaluating whether the throttle's assumption-free drawdown improvement and DHT's funding-carry-dependent improvement compose additively or substitute for one another over the same sample."),
  ]),
];

// ============================================================
// SECTION VII. CONCLUSION
// ============================================================
const sectionVII = [
  sectionHeading("CONCLUSION", "VII"),
  bodyPara([
    run("Building on the DGT mechanism of [1] and structurally distinct from our earlier DGTAP extension [2], we proposed Dynamic Hedge-grid Trading (DHT): a reverse perpetual-futures hedge layered directly into DGT's down-break recycle event, recomputed against the full accumulated spot position at every recycle and paired with a per-recycle grid-widening schedule. On 3.5 years of real Bitcoin minute-resolution data, at an operating point selected through a reset-count-constrained search (hedge_ratio\u2009=\u20090.6, stepCycleAdd\u2009=\u20090.005), DHT improves the Calmar ratio from DGT's 0.436 to 1.294, simultaneously raising IRR and roughly halving maximum drawdown. This result is genuinely conditional, not unconditional: it depends materially on an assumed favorable funding-rate regime (Section V-E), on a hedge-parameter surface shown to be considerably less smooth than DGT's own grid-size surface (Section V-C), and does not transfer cleanly to a different bar-sampling frequency without re-tuning (Section V-F). We also documented two implementation pitfalls \u2014 a degenerate global-exit condition and an unmargined hedge capable of producing impossible negative equity \u2014 and the fixes adopted for each, in the same spirit of explicit uncertainty and pitfall reporting established in [2]. We regard the honest characterization of these three open sensitivities, together with the two implementation pitfalls, as being as valuable a contribution of this paper as the headline point estimate itself. Future work should validate the proposed operating point against ETH and multiple non-overlapping historical windows, replace the fixed hedge_ratio with a formally estimated minimum-variance hedge ratio [7], evaluate a combined DHT+throttle variant against DGTAP directly, and test the statistical significance of the reported Calmar improvement against a resampled or bootstrapped null using the deflated-Sharpe methodology of [9]."),
  ]),
];

// ============================================================
// REFERENCES
// ============================================================
const references = [
  new Paragraph({
    children: [boldRun("REFERENCES", { size: 21 })],
    spacing: { before: 240, after: 120 },
  }),
  refPara("[1] K.-Y. Chen, K.-H. Chen, and J.-S. R. Jang, \u201cDynamic Grid Trading Strategy: From Zero Expectation to Market Outperformance,\u201d arXiv preprint arXiv:2506.11921, 2025."),
  refPara("[2] [Authors], \u201cDynamic Grid Trading with Anti-Martingale Sizing and Protective Options: An Extension Toward Bounded Tail Risk,\u201d unpublished manuscript, 2026."),
  refPara("[3] A. Schmeling, A. Schrimpf, and K. Todorov, \u201cCrypto Carry,\u201d BIS Working Papers, no. 1087, 2023."),
  refPara("[4] K. Alexander, D. Choi, and A. Park, \u201cThe Economics of Cryptocurrency Perpetual Futures Funding Rates,\u201d working paper, 2022."),
  refPara("[5] C. Alexander, D. Deng, and Y. Feng, \u201cSystemic Risk in Cryptocurrency Perpetual Futures Markets,\u201d working paper, 2023."),
  refPara("[6] J. C. Hull, Options, Futures, and Other Derivatives, 10th ed. Boston: Pearson, 2018, ch. 3."),
  refPara("[7] L. L. Johnson, \u201cThe Theory of Hedging and Speculation in Commodity Futures,\u201d Review of Economic Studies, vol. 27, no. 3, pp. 139\u2013151, 1960."),
  refPara("[8] Y. Chen, Y. Ma, and B. Zheng, \u201cLiquidation Cascades in Cryptocurrency Perpetual Futures Markets,\u201d working paper, 2023."),
  refPara("[9] D. H. Bailey and M. L\u00f3pez de Prado, \u201cThe Deflated Sharpe Ratio: Correcting for Selection Bias, Backtest Overfitting, and Non-Normality,\u201d Journal of Portfolio Management, vol. 40, no. 5, pp. 94\u2013107, 2014."),
  refPara("[10] D. H. Bailey, J. Borwein, M. L\u00f3pez de Prado, and Q. J. Zhu, \u201cThe Probability of Backtest Overfitting,\u201d Journal of Computational Finance, vol. 20, no. 4, pp. 39\u201369, 2017."),
];

// ============================================================
// APPENDIX
// ============================================================
const appendix = [
  new Paragraph({
    children: [boldRun("APPENDIX A", { size: 21 }), boldRun("  CODE AND REPRODUCIBILITY", { size: 21 })],
    spacing: { before: 240, after: 120 },
  }),
  bodyPara([
    run("The DHT backtesting implementation (grid engine, recycle-triggered hedge resizing, funding accrual, and margin-liquidation guard) is implemented in Python (dht_backtest.py) and was run against the Bitstamp dataset described in Section IV, using the same DGT-baseline code path validated against [2]. It reproduces the DGT mechanism from the published algorithm description in [1] rather than the released source accompanying that paper, and the DGT baseline figures reported here (Table II) should therefore be compared only to the DGT figures reported within this paper series [2], not treated as an exact reproduction of [1]'s own absolute figures. All parameter sweeps referenced in Section V, including the hourly-bar robustness check of Section V-F and the funding-rate sensitivity of Section V-E, are included with the accompanying code release."),
  ]),
];

// ============================================================
// ASSEMBLE DOCUMENT
// ============================================================
const doc = new Document({
  styles: {
    default: {
      document: { run: { font: FONT, size: 20 } },
    },
  },
  sections: [
    {
      properties: {
        page: {
          size: { width: 12240, height: 15840 },
          margin: { top: 1080, right: 900, bottom: 1440, left: 900, header: 708, footer: 708, gutter: 0 },
        },
        type: SectionType.CONTINUOUS,
      },
      children: titleBlock,
    },
    {
      properties: {
        page: {
          size: { width: 12240, height: 15840 },
          margin: { top: 1080, right: 900, bottom: 1440, left: 900, header: 708, footer: 708, gutter: 0 },
        },
        column: { count: 2, space: 288 },
        type: SectionType.CONTINUOUS,
      },
      children: [
        ...sectionI,
        ...sectionII,
        ...sectionIII,
        ...sectionIV,
        ...sectionV,
        ...sectionVI,
        ...sectionVII,
        ...references,
        ...appendix,
      ],
    },
  ],
});

Packer.toBuffer(doc).then(buffer => {
  fs.writeFileSync("DHT_IEEE.docx", buffer);
  console.log("Written DHT_IEEE.docx");
});
