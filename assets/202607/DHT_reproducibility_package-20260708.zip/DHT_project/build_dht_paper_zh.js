const fs = require("fs");
const {
  Document, Packer, Paragraph, TextRun, AlignmentType,
  Table, TableRow, TableCell, WidthType, ShadingType, BorderStyle,
  ImageRun, SectionType, VerticalAlign, TableLayoutType,
} = require("docx");

const FONT_EN = "Times New Roman";
const FONT_CJK = "Noto Serif CJK SC";

// ---------- helpers ----------
function run(text, opts = {}) {
  return new TextRun({
    text,
    font: { name: FONT_EN, eastAsia: FONT_CJK },
    size: 20,
    ...opts,
  });
}
function italicRun(text, opts = {}) {
  return run(text, { italics: true, ...opts });
}
function boldRun(text, opts = {}) {
  return run(text, { bold: true, ...opts });
}

function bodyPara(children, opts = {}) {
  return new Paragraph({
    children: Array.isArray(children) ? children : [children],
    spacing: { after: 120, line: 300 },
    alignment: AlignmentType.JUSTIFIED,
    ...opts,
  });
}

function sectionHeading(text, numeral) {
  return new Paragraph({
    children: [boldRun(`${numeral}. ${text}`, { size: 21 })],
    spacing: { before: 240, after: 120 },
    alignment: AlignmentType.LEFT,
  });
}

function subHeading(letter, text) {
  return new Paragraph({
    children: [italicRun(`${letter}. ${text}`, { bold: true, size: 20 })],
    spacing: { before: 160, after: 80 },
  });
}

function figureImage(path, widthPx, heightPx, maxWidthIn = 3.35) {
  const aspect = heightPx / widthPx;
  const wIn = Math.min(maxWidthIn, widthPx / 300);
  const hIn = wIn * aspect;
  // Distortion fix: pass unrounded float pixel values so docx's own
  // fine-grained EMU-stage rounding preserves the true aspect ratio,
  // rather than pre-rounding to integer pixels ourselves.
  return new Paragraph({
    children: [
      new ImageRun({
        data: fs.readFileSync(path),
        transformation: { width: wIn * 96, height: hIn * 96 },
        type: "png",
      }),
    ],
    alignment: AlignmentType.CENTER,
    spacing: { before: 120, after: 60 },
  });
}

// FONT-SIZE FIX (3rd pass, same rationale as English edition): the 2nd-pass
// fix anchored the scale on a 9.5pt target character size, chosen only to
// avoid overflow -- but that made equations smaller than the 10pt body
// text itself, illegible at normal viewing/printing resolution. DGTAP's
// own inline images (measured directly from its docx) average ~18.4pt
// tall; DHT's equations now anchor to that same scale so they match
// DGTAP's visual weight and are legible, rather than an arbitrary,
// too-small target picked only to avoid overflow.
const EQ_DPI = 300;
const EQ_TARGET_CHAR_PT = 18.4;
const EQ_MAX_WIDTH_IN = 2.9;
function computeGlobalEqScale(singleLineHeightsPx, widestWidthPx) {
  const refHeightPx = singleLineHeightsPx.reduce((a, b) => a + b, 0) / singleLineHeightsPx.length;
  let scale = (EQ_TARGET_CHAR_PT / 72 * EQ_DPI) / refHeightPx;
  // If the widest equation in the whole set would overflow the column at
  // this scale, shrink the scale globally (applied to every equation
  // equally) just enough that the widest one fits -- capping only the
  // one offending equation would make it look smaller than its neighbors.
  const widestWidthIn = (widestWidthPx / EQ_DPI) * scale;
  if (widestWidthIn > EQ_MAX_WIDTH_IN) {
    scale = EQ_MAX_WIDTH_IN / (widestWidthPx / EQ_DPI);
  }
  return scale;
}

function eqImage(path, widthPx, heightPx, label, globalScale) {
  const wIn = (widthPx / EQ_DPI) * globalScale;
  const hIn = (heightPx / EQ_DPI) * globalScale;
  // Distortion fix: pass unrounded float pixel values (docx does its own
  // fine-grained rounding at the EMU stage internally); pre-rounding to
  // integer pixels ourselves at these small target sizes (~12-24px tall)
  // was discarding enough precision to visibly distort the aspect ratio.
  const wPx = wIn * 96;
  const hPx = hIn * 96;
  // LAYOUT FIX: PERCENTAGE width with default AUTOFIT layout lets Word/
  // LibreOffice recalculate column widths based on content, and since the
  // image itself is small, the renderer can collapse the whole table --
  // including the equation's display size -- into a cramped clump
  // regardless of the requested transformation width/height. Fixed DXA
  // column widths plus explicit FIXED layout (same technique as makeTable())
  // force the renderer to honor the requested size exactly.
  const colWidthDxa = 4680;
  const imgColDxa = Math.round(colWidthDxa * 0.82);
  const labelColDxa = colWidthDxa - imgColDxa;
  return new Table({
    width: { size: colWidthDxa, type: WidthType.DXA },
    columnWidths: [imgColDxa, labelColDxa],
    layout: TableLayoutType.FIXED,
    margins: { top: 0, bottom: 0, left: 20, right: 20 },
    borders: {
      top: { style: BorderStyle.NONE, size: 0, color: "FFFFFF" },
      bottom: { style: BorderStyle.NONE, size: 0, color: "FFFFFF" },
      left: { style: BorderStyle.NONE, size: 0, color: "FFFFFF" },
      right: { style: BorderStyle.NONE, size: 0, color: "FFFFFF" },
      insideHorizontal: { style: BorderStyle.NONE, size: 0, color: "FFFFFF" },
      insideVertical: { style: BorderStyle.NONE, size: 0, color: "FFFFFF" },
    },
    rows: [
      new TableRow({
        cantSplit: true,
        children: [
          new TableCell({
            width: { size: imgColDxa, type: WidthType.DXA },
            verticalAlign: VerticalAlign.CENTER,
            margins: { top: 0, bottom: 0, left: 0, right: 0 },
            children: [new Paragraph({
              children: [new ImageRun({
                data: fs.readFileSync(path),
                transformation: { width: wPx, height: hPx },
                type: "png",
              })],
              alignment: AlignmentType.CENTER,
            })],
          }),
          new TableCell({
            width: { size: labelColDxa, type: WidthType.DXA },
            verticalAlign: VerticalAlign.CENTER,
            margins: { top: 0, bottom: 0, left: 0, right: 0 },
            children: [new Paragraph({
              children: [run(`(${label})`, { size: 20 })],
              alignment: AlignmentType.RIGHT,
            })],
          }),
        ],
      }),
    ],
  });
}



function figCaption(text) {
  return new Paragraph({
    children: [run(text, { size: 18 })],
    alignment: AlignmentType.CENTER,
    spacing: { after: 200 },
  });
}

function makeTable(headerCells, rows, colWidths) {
  const totalWidth = 4680;
  const widths = colWidths || headerCells.map(() => Math.floor(totalWidth / headerCells.length));
  const headerRow = new TableRow({
    tableHeader: true,
    cantSplit: true,
    children: headerCells.map((h, i) => new TableCell({
      width: { size: widths[i], type: WidthType.DXA },
      shading: { type: ShadingType.CLEAR, fill: "D9D9D9" },
      children: [new Paragraph({
        children: [boldRun(h, { size: 16 })],
        alignment: AlignmentType.CENTER,
      })],
    })),
  });
  const bodyRows = rows.map(r => new TableRow({
    cantSplit: true,
    children: r.map((cellText, i) => new TableCell({
      width: { size: widths[i], type: WidthType.DXA },
      children: [new Paragraph({
        children: [run(String(cellText), { size: 16 })],
        alignment: i === 0 ? AlignmentType.LEFT : AlignmentType.CENTER,
      })],
    })),
  }));
  return new Table({
    width: { size: totalWidth, type: WidthType.DXA },
    columnWidths: widths,
    rows: [headerRow, ...bodyRows],
  });
}

function tableCaption(label, text) {
  return new Paragraph({
    children: [run(`${label}`, { size: 16 }), run(`\n${text}`, { size: 16 })],
    alignment: AlignmentType.CENTER,
    spacing: { before: 160, after: 80 },
    keepNext: true,
  });
}

function refPara(text) {
  return new Paragraph({
    children: [run(text, { size: 18 })],
    spacing: { after: 100 },
    alignment: AlignmentType.JUSTIFIED,
  });
}

const M = "paper_media/";

const EQ_SCALE = computeGlobalEqScale([
  124, // eq2 (single-line)
  134, // eq3 (single-line)
  134, // eq4 (single-line)
  134, // eq5 (single-line)
  134, // eq7 (single-line)
], 2202); // eq7 is the widest equation in the paper

// ============================================================
// 标题区块（单栏）
// ============================================================
const titleBlock = [
  new Paragraph({
    children: [boldRun(
      "动态对冲网格交易策略：将反向永续期货对冲部位层叠于动态网格交易的循环加仓机制之中",
      { size: 32 }
    )],
    alignment: AlignmentType.CENTER,
    spacing: { after: 200 },
  }),
  new Paragraph({
    children: [run("［作者姓名待填］", { size: 22 })],
    alignment: AlignmentType.CENTER,
    spacing: { after: 40 },
  }),
  new Paragraph({
    children: [run("［作者單位待填］", { size: 22 })],
    alignment: AlignmentType.CENTER,
    spacing: { after: 40 },
  }),
  new Paragraph({
    children: [run("2026年7月", { size: 22 })],
    alignment: AlignmentType.CENTER,
    spacing: { after: 200 },
  }),

  new Paragraph({
    children: [
      italicRun("溯源说明：", { bold: true, size: 20 }),
      italicRun(
        "本文建立在陈、陈与张（Chen, Chen, and Jang）[1] 提出的动态网格交易（“DGT”）之上，亦承接我们先前的扩展工作——具反鞅式仓位调节与保护性期权的动态网格交易（“DGTAP”）[2]。DGT 的重置机制与零期望值证明引用自 [1]，本文不再重复推导。本文提出的扩展——以层叠于 DGT 向下突破循环加仓事件中的反向永续期货对冲部位，取代 DGTAP 的反鞅式节流阀与保护性买权覆盖层，合称为动态对冲网格交易（DHT）——连同第五节中的所有回测结果，皆为本文原创，并依第四节所述方法，以真实市场数据独立完成。",
        { size: 20 }
      ),
    ],
    spacing: { after: 160 },
    alignment: AlignmentType.JUSTIFIED,
  }),

  new Paragraph({
    children: [
      italicRun("摘要—", { bold: true, size: 20 }),
      italicRun(
        "动态网格交易（DGT）[1] 透过在价格突破交易区间边界时，全数换为现金或全数换为库存部位，并于突破价重新置中网格，打破了传统网格策略的零期望值特性。这项向下突破的“循环加仓”规则，同时也是 DGT 的主要残余风险来源：它会在持续下跌趋势中集中买入。我们先前的研究 DGTAP [2] 以连续成交反鞅式节流阀与期权型尾部风险对冲加以应对。本文提出一个结构上截然不同的扩展——动态对冲网格交易（DHT）——不采用缩减仓位大小的方式，而是将反向（空头）永续期货对冲直接层叠于每一次向下突破的循环加仓事件之中。每次循环加仓时，DHT（一）依原始 DGT 规则部署循环加仓的第一层现货部位，（二）依固定比例（hedge_ratio）针对当前“大循环”开始以来累积的*全部*净现货部位重新计算空头永续期货对冲部位，（三）每次循环加仓后将网格间距扩大一个固定增量（stepCycleAdd）。当现货加对冲的综合权益（扣除资金费率后）回复至大循环起始权益以上时，大循环即出场并重启。在 3.5 年的真实分钟级 BTC/USD 数据（Bitstamp，2021 年 1 月至 2024 年 7 月）上，采用与 DGTAP 类似的、以重置次数为门槛的搜索方法，在 hedge_ratio = 0.6、stepCycleAdd = 0.005，并假设年化 +10% 资金费率（依永续合约资金费率的标准惯例，此对 DHT 的空头对冲部位有利）的操作点下，Calmar 比率由 DGT 的 0.436 提升至 1.294，同时年化报酬率（IRR）由 20.20% 提升至 29.74%，最大回撤（MDD）由 −46.29% 降至约一半的 −22.99%。我们报告开发过程中发现的两项方法论缺陷——全局获利出场条件的规格模糊导致在对冲机制尚未启动前即发生虚假重启，以及未设保证金限制的按市值计价模型在部分参数设定下产生不可能出现的负权益路径——并说明各自采用的修正方法。我们进一步显示，本文的主要结果对资金费率假设（约在年化 +7% 至 8% 处存在体制转换，低于此门槛 DHT 并不优于 DGT）以及K棒取样频率（以一分钟数据调校出的操作点无法直接套用于小时线）皆高度敏感，并明确报告这两项敏感度分析，而非仅呈现单一点估计值。",
        { size: 20 }
      ),
    ],
    spacing: { after: 160 },
    alignment: AlignmentType.JUSTIFIED,
  }),

  new Paragraph({
    children: [
      italicRun("索引词—", { bold: true, size: 20 }),
      italicRun("算法交易、网格交易、加密货币、永续期货、资金费率、对冲、尾部风险、回测过拟合、比特币。", { size: 20 }),
    ],
    spacing: { after: 120 },
  }),
];

// ============================================================
// 第一节 引言
// ============================================================
const sectionI = [
  sectionHeading("引言", "I"),
  bodyPara([
    run("本文建立在陈、陈与张 [1] 提出的重置式网格策略——动态网格交易（DGT）之上，亦承接我们先前的扩展工作 DGTAP [2]，为求自洽，在此简要概述。网格交易在参考价格周围布置 "),
    italicRun("n"),
    run(" 个等距或等比间隔的价格层级，价格上穿某一层级时机械性卖出库存部位，下穿时则买回。在对称随机游走假设下，此传统规则在计入手续费前的期望利润为零 [1]。DGT 以单一结构性改变打破了这项结果：当价格突破交易区间边界时，策略不会停止，而是全数转为现金（上边界突破）或全数投入资金（下边界突破），接着在突破价重新置中一个全新网格并继续运行。这种在边界处的资金循环再利用，正是 DGT 实现其真实优势的来源，同时也是其主要残余风险的成因：持续的下跌趋势会引发反复的下边界突破，每一次都会在任何反弹发生之前，将更多资金投入一个持续下跌的资产。"),
  ]),
  bodyPara([
    run("在 DGTAP [2] 中，我们以两项与网格并行运作的机制应对此残余风险：一是连续成交反鞅式仓位节流阀，会在持续下跌走势中缩减买入侧的仓位大小；二是定期展期的价外保护性买权，以钱包中固定的小比例资金支应。节流阀带来了稳健且不依赖额外假设的改善（Calmar 由 0.436 提升至 0.538）；而买权覆盖层的边际价值则高度取决于一个无法观测的隐含波动率与实现波动率比值假设，其效果依该假设的不同，从几乎打平到 Calmar 比率近乎翻倍不等。"),
  ]),
  bodyPara([
    run("本文探讨一个结构上截然不同的扩展方向。动态对冲网格交易（DHT）并不缩减现货买入的仓位大小，也不购买会随时间衰减的期权部位，而是将一个"),
    italicRun("反向永续期货对冲部位"),
    run("直接附加于 DGT 自身的向下突破循环加仓事件之上。永续期货目前已是各大交易所建立加密货币空头曝险的主流工具，具备深厚的流动性与持续的资金费率价格发现机制，且不会像期权部位那样随时间衰减——这与 DGTAP 的买权覆盖层在风险转移机制上有本质差异，因此值得独立评估，而非视为同一构想的参数变体。"),
  ]),
  bodyPara([
    run("每当 DGT 的下边界被突破时，DHT（一）会如同原始 DGT 一般，部署此次循环加仓的第一层现货部位；（二）依固定比例 hedge_ratio，针对当前“大循环”开始以来累积的"),
    italicRun("全部"),
    run("净现货部位（而非仅新增的这一层）重新计算空头永续期货对冲部位；（三）每次循环加仓后，将网格间距扩大一个固定增量 stepCycleAdd，使得同一波不利行情中连续发生的循环加仓，其再入场价位间距逐次拉开。大循环——可能跨越多次循环加仓——会在现货加对冲的综合权益（扣除资金费率后）回复至起始权益以上时出场并重启。本文精确定义此机制（第三节），记录实作过程中发现的两项方法论缺陷（第五节 A、B 小节，秉持 DGTAP 对其自身覆盖层揭露缺陷时的同样精神），并报告回测结果及其对资金费率假设与K棒取样频率的敏感度（第五节 E、F 小节），此举延续本系列论文一贯的做法：明确揭露真实存在的建模不确定性，而非将其简化为单一数字。"),
  ]),
];

// ============================================================
// 第二节 相关研究
// ============================================================
const sectionII = [
  sectionHeading("相关研究", "II"),
  bodyPara([
    run("网格交易及其零期望值基准、DGT 的边界重置机制，以及 DGTAP 的反鞅式节流阀与保护性买权覆盖层，已分别在 [1] 与 [2] 中详细回顾，本文不再重复。本节聚焦于 DHT 新机制所涉及的文献：永续期货、资金费率，以及以期货工具进行的德尔塔对冲。"),
  ]),
  subHeading("A", "永续期货与资金费率"),
  bodyPara([
    run("永续期货合约由 BitMEX 引入加密货币市场，如今已是多数主要交易所中按成交量计算的主流衍生性商品工具，其没有到期日；取而代之的是多头与空头持仓者之间定期直接交换的资金费率支付，用以将合约价格锚定于现货指数 [3]。当永续合约价格高于现货时，多头支付空头（正资金费率）；低于现货时，则空头支付多头（负资金费率）。针对比特币与以太坊永续合约实现资金费率分布的实证研究显示，资金费率在多年期样本中通常为正，但并非总是如此，且存在相当程度的体制相关变化，并在剧烈下跌或过度拥挤的多头部位平仓后，偶尔出现持续性的负资金费率区间 [4]、[5]。这种不对称性——当市场普遍呈现正资金费率的惯例成立时，空头对冲部位为资金费率的净收取方，但在负资金费率体制下则转为净支付方——是第五节 E 小节敏感度分析的核心。"),
  ]),
  subHeading("B", "以期货进行的德尔塔对冲"),
  bodyPara([
    run("以对冲性期货部位来对冲现货或实物部位，是早于加密货币市场数十年的经典风险管理技术 [6]，而最小方差对冲比率的估计——选择使综合部位方差最小化的对冲规模——则是大宗商品与金融期货领域中已被充分研究的问题 [7]。DHT 的 hedge_ratio 参数是此最小方差对冲比率的简化、固定比例类比，并未采用正式的方差最小化估计步骤；第七节将以正式估计的最小方差对冲比率列为未来精进的具体方向。与持续再平衡的最小方差对冲不同，DHT 的对冲部位仅在离散的循环加仓事件时重新调整规模，这是刻意的设计选择，呼应了 DGT 本身在网格边界处采用离散（而非连续）再平衡的方式。"),
  ]),
  subHeading("C", "保证金与强制平仓机制"),
  bodyPara([
    run("杠杆永续部位须满足维持保证金要求，一旦亏损超过已存入的保证金即会遭强制平仓；交易所技术文献已记载全仓与逐仓强制平仓引擎的运作机制，包括保险基金与自动减仓，并有实证研究探讨其在剧烈波动期间对连锁强制平仓事件的影响 [8]。第五节 B 小节记录了 DHT 回测早期版本中一项未对对冲部位设置任何保证金限制的缺陷，以及为此采用的简化强制平仓上限修正方式。"),
  ]),
  subHeading("D", "回测过拟合与风险调整后绩效指标"),
  bodyPara([
    run("如同 [2]，本文通篇依赖 Calmar 比率，并谨记回测过拟合文献对于在单一历史路径上进行无约束参数优化的警示 [9]、[10]。DGTAP 记录了两项相关缺陷——网格参数搜索中的重采样偏差，以及无约束优化退化为零交易情形——并采用重置次数门槛作为启发式防护。本文第五节将类似的防护措施套用于 DHT 的 hedge_ratio／stepCycleAdd 参数曲面，并记录了第三项相关但不同的缺陷：即便套用了重置次数门槛，该参数曲面在无约束搜索下仍高度非单调，这与 DGTAP 较为平滑的网格大小曲面不同。"),
  ]),
];

// ============================================================
// 第三节 DHT：提出的机制（含公式）
// ============================================================
const sectionIII = [
  sectionHeading("DHT：提出的机制", "III"),
  subHeading("A", "回顾 DGT 的循环加仓事件"),
  bodyPara([
    run("我们在定义 DHT 所需的程度上重述 DGT 的边界规则；完整推导请参见 [1]，我们先前的重述则见 [2，第 III-A 节]。一个等比网格由中心价格 "),
    italicRun("P"), run("\u2080、每层比率 "), italicRun("k"), run(" 与半宽 "), italicRun("m"), run(" 定义，共产生 "), italicRun("2m+1"),
    run(" 个层级。当价格突破上边界 "), italicRun("P"), run("\u2080(1+"), italicRun("k"), run(")"), italicRun("\u1d50"),
    run(" 时，策略全数换为现金；突破下边界 "), italicRun("P"), run("\u2080(1+"), italicRun("k"), run(")"), italicRun("\u207b\u1d50"),
    run(" 时，则全数换为库存部位。随后在突破价重新置中一个全新网格。DHT 仅修改此规则的"),
    italicRun("下边界"),
    run("（逢低买入方向）分支；上边界突破则完全依照原始 DGT 处理，不会触发任何对冲行为或网格加宽，此设计决策的用意是让 DHT 的风险管理机制专门针对 DGT 自身架构会集中风险的下方加仓事件而启动。"),
  ]),
  subHeading("B", "DHT 的循环加仓事件"),
  bodyPara([
    run("我们将 DHT "), italicRun("大循环"), run(" 内的每一次下边界突破称为一次"), italicRun("循环加仓"),
    run("。大循环以起始权益 "), italicRun("E"), run("\u2080（全数为现金）与一个以基础间距 "), italicRun("k"),
    run("\u2090\u2090\u2090\u2090 重新置中的全新网格开始。在当前大循环内的第 "), italicRun("r"), run(" 次循环加仓时："),
  ]),
  bodyPara([
    run("1）将全部剩余现金以突破价投入现货，完全依照原始 DGT 下边界规则执行（即此次循环加仓的“第一层”）。"),
  ]),
  bodyPara([
    run("2）对冲部位将被完整重新计算——而非增量调整——其计算基础为大循环开始以来所持有的全部净现货数量："),
  ]),
  eqImage(M + "eq1_hedge_qty.png", 1493, 159, "1", EQ_SCALE),
  bodyPara([
    run("其中 hedge_ratio\u2009\u2208\u2009[0,1] 为固定配置参数（第五节报告了针对此参数的搜索结果，包括作为对照组的 hedge_ratio\u2009=\u20090 无对冲情形）。任何先前已开启的对冲部位都会被平仓——其价格损益结算入现货钱包——并在突破价重新开立一笔规模为 "),
    italicRun("Q"), run("\u2095\u2091\u2091\u2091\u2091 的空头部位。以完整累积部位（而非仅新增的一层）作为对冲计算基础，意味着对冲部位能直接追踪"),
    italicRun("累积性"), run("的、由下跌驱动的库存部位累积过程，其代价是每次循环加仓都必须将整个对冲部位平仓并重新开立（因而产生重新入场的基差成本）。"),
  ]),
  bodyPara([
    run("3）网格间距每次循环加仓将扩大一个固定增量 stepCycleAdd："),
  ]),
  eqImage(M + "eq2_widening.png", 1666, 124, "2", EQ_SCALE),
  bodyPara([
    run("如此一来，在同一波持续的不利行情中连续发生的循环加仓，其再入场价位间距会逐次拉开，随着不利行情持续，降低新增资金投入的频率——这是与 DGTAP 节流阀（缩减每次成交投入的现金"),
    italicRun("比例"), run("）不同的风险缩减机制，但设计意图相关：两种机制皆针对相对于第一次事件而言的第 "),
    italicRun("n"), run(" 次连续同方向事件进行降险处理。"),
  ]),
  bodyPara([
    run("4）在新的、更宽的网格上，买入侧的仓位大小重新以网格常规的第一层比例起算；DHT 不沿用连续成交节流阀，因为在此设计中，降险的角色已交由对冲部位承担。"),
  ]),
  subHeading("C", "资金费率计提与对冲部位按市值计价"),
  bodyPara([
    run("每根K棒都会依当前开启的对冲部位名目金额，以一个固定假设的年化费率 "), italicRun("f"), run("\u2090\u209a\u1d63 计提资金费率："),
  ]),
  eqImage(M + "eq3_funding.png", 1435, 134, "3", EQ_SCALE),
  bodyPara([
    run("由于 DHT 的对冲部位为空头，正的 "), italicRun("f"), run("\u2090\u209a\u1d63（依第二节 A 小节所述，此为历史上较典型的符号）对其构成顺风：对冲部位可收取资金费率，此与多头支付空头为正资金费率的标准惯例一致。对冲部位的未实现价格损益，每根K棒依下式计价："),
  ]),
  eqImage(M + "eq4_hedge_pnl.png", 1563, 134, "4", EQ_SCALE),
  bodyPara([
    run("而用于报告权益曲线及大循环出场判断的综合按市值计价权益为："),
  ]),
  eqImage(M + "eq5_combined_equity.png", 1646, 134, "5", EQ_SCALE),
  subHeading("D", "全局获利出场条件"),
  bodyPara([
    run("大循环会在综合权益首次收在大循环起始权益之上（所有部位平仓、重新置中一个新网格、stepCycleAdd 归零），"), italicRun("且"),
    run("当前大循环内已发生至少一次循环加仓时结束（第五节 A 小节说明为何需要这第二项条件）："),
  ]),
  eqImage(M + "eq6_exit_condition.png", 1640, 162, "6", EQ_SCALE),
  subHeading("E", "对冲部位保证金与强制平仓"),
  bodyPara([
    run("真实的空头永续部位须存入保证金，一旦亏损超过该保证金即会遭交易所强制平仓；它不能像一个未设保证金限制的按市值计价请求权那样，在简化的模拟中将投资组合的其余部分拖累至任意的负值（第五节 B 小节记录了此项防护措施所针对的失效模式）。我们将每个对冲部位所能容忍的亏损上限，设为其开仓名目金额的一个固定比例："),
  ]),
  eqImage(M + "eq7_liquidation.png", 2202, 134, "7", EQ_SCALE),
  bodyPara([
    run("本文通篇采用 margin_frac\u2009=\u20090.5。一旦触及此上限，对冲部位将于该亏损水位被强制平仓，并将亏损计入钱包，而不允许其继续扩大。这是对真实全仓／逐仓保证金机制（其中还涉及部分强制平仓、保险基金与强制平仓价格滑价）的简化处理，其采用目的是为了避免回测报告出现真实交易所部位不可能产生的权益路径。"),
  ]),
  subHeading("F", "综合算法与评估指标"),
  bodyPara([
    run("DHT 即是 DGT，其下边界分支依第三节 B 小节的步骤（1）至（3）扩展，并搭配依第三节 C 至 E 小节管理的平行空头永续对冲部位；上边界（获利了结）分支则维持原始 DGT 不变。如同 [1] 与 [2]，绩效以年化 IRR、最大回撤（MDD）与 Calmar 比率总结："),
  ]),
  eqImage(M + "eq8_irr.png", 906, 191, "8", EQ_SCALE),
  eqImage(M + "eq9_mdd.png", 1189, 269, "9", EQ_SCALE),
  eqImage(M + "eq10_calmar.png", 761, 182, "10", EQ_SCALE),
  bodyPara([
    run("其中 "), italicRun("V"), run("\u2080 与 "), italicRun("V"), run("\u1d40 分别为期初与期末综合权益，"), italicRun("T"), run("\u1d67\u1d63 为样本期间的年数，"), italicRun("V"), run("\u209c 则为方程式 5 所定义的按市值计价综合权益曲线。"),
  ]),
  new Paragraph({ children: [], spacing: { after: 40 } }),
  tableCaption("表一", "第三节所用符号汇总"),
  makeTable(
    ["符号", "意义"],
    [
      ["P\u2080, k, m", "网格中心价格、层级比率、半宽"],
      ["r, stepCycleAdd", "循环加仓次数；每次加仓的间距增量"],
      ["hedge_ratio, Q hedge, Q spot", "对冲比例；空头对冲与净现货数量"],
      ["f_apr, \u0394t, \u03a0 hedge(P_t)", "资金费率；K棒时长；对冲部位损益"],
      ["E_t, E\u2080, margin_frac", "综合／起始权益；保证金强平上限"],
      ["V_t, IRR, MDD", "权益曲线；年化报酬率；最大回撤"],
    ],
    [1900, 2780]
  ),
];

// ============================================================
// 第四节 数据
// ============================================================
const sectionIV = [
  sectionHeading("数据与实验设置", "IV"),
  bodyPara([
    run("所有结果皆采用真实的交易所数据：Bitstamp BTC/USD，一分钟解析度，自 2021 年 1 月 1 日至 2024 年 7 月 31 日（共 1,882,081 根K棒），此为 [2] 所用的相同数据集与时间窗口，亦与 [1] 的评估窗口一致。每次网格成交皆计入 8 个基点（0.0008）的双向手续费，且所有报告数字的初始资金皆正规化为 100 单位，与 [2] 一致。对冲部位除方程式 3 所述的资金费率计提外（第六节 C 小节），不另计交易所手续费或买卖价差。"),
  ]),
  bodyPara([
    run("如同 [2]，本研究在现有条件限制下未能取得可比拟的真实分钟级 ETH 数据；所有结果仅限于 BTC，此为承袭自前作并于第六节进一步讨论的限制。"),
  ]),
];

// ============================================================
// 第五节 结果
// ============================================================
const sectionV = [
  sectionHeading("结果", "V"),
  subHeading("A", "缺陷一：退化的全局获利出场条件"),
  bodyPara([
    run("初版实作在每根K棒都会检查全局获利出场条件（方程式 6，未加入循环加仓次数防护）。由于一般的 DGT 式网格交易在真正的下跌发生之前接近零期望值，当网格停留在中心附近、仅持有少量残余部位时，综合权益几乎在任何一根K棒上都会回复至起始值——即便从未发生过任何循环加仓或对冲。在针对样本前 5,000 根K棒的诊断测试中，此现象在第一次循环加仓事件真正触发之前，就已引发超过 100 次虚假重启，这意味着若按字面实作出场规则，DHT 的对冲机制实际上永远不会真正启动。我们的解决方式是将出场检查的条件设为 "),
    italicRun("r"), run(" > 0（方程式 6）：唯有在当前大循环内至少发生过一次向下侧循环加仓——因而存在一个实际运作中的对冲部位——之后，才会评估全局出场条件。我们明确将此列为规格上的精进说明，而非默默修补，这延续了本系列论文一贯揭露模糊之处而非隐藏的做法。"),
  ]),
  subHeading("B", "缺陷二：未设保证金限制的对冲部位产生不可能出现的负权益"),
  bodyPara([
    run("对 hedge_ratio 与 stepCycleAdd 的敏感度测试发现，部分参数组合（例如 hedge_ratio\u2009=\u20090.7、stepCycleAdd\u2009=\u20090.02）会使期末权益由 100 美元起始转为负值。根本原因在于：在深度下跌中开立的对冲部位，会一直维持原状、不重新调整规模，直到"),
    italicRun("下一次"), run("循环加仓发生为止；倘若在下一次下边界突破发生之前，价格已大幅反弹——正如 2022 年低点附近开立的对冲部位，其后遭遇比特币于 2024 年 3 月创下历史新高的行情——该对冲部位在未设任何保证金限制的情况下，其未实现亏损可能多倍超过整个起始投资组合的价值。这并非真实空头永续部位的实际行为：真实交易所会在亏损超过已存入保证金时强制平仓，远早于该亏损足以拖累钱包其余部分之前。因此，我们采用了方程式 7 的强制平仓上限（margin_frac\u2009=\u20090.5）；采用此上限后，第五节 C 小节中测试的所有参数组合皆产生有界、合理的回撤，且不再出现负权益路径。"),
  ]),
  subHeading("C", "以重置次数为约束条件的参数搜索"),
  bodyPara([
    run("仿照 [2] 采用的重置次数门槛（用以防范重置事件次数过少、不具统计意义的网格配置），我们在固定网格参数（k\u2009=\u20092.5%、m\u2009=\u20096，此即 [2，表五] 中为原始 DGT 找出的 Calmar 最优操作点）下，搜索 hedge_ratio\u2009\u2208\u2009{0.0,\u20090.1,\u2026,\u20091.0} 与 stepCycleAdd\u2009\u2208\u2009{0,\u20090.0025,\u20090.005,\u2026,\u20090.03}，并仅保留在 3.5 年样本期间内至少发生 15 次循环加仓事件的组合（88 组中的 71 组）。"),
  ]),
  figureImage(M + "fig1_dht_heatmap.png", 1240, 860),
  figCaption("图一。hedge_ratio 与 stepCycleAdd 组合下的 Calmar 比率（循环加仓次数 \u2265 15 之防护条件，原生一分钟 BTC 数据）。此曲面呈非单调分布：相同 hedge_ratio 下的相邻格点，Calmar 比率经常在强烈正值与接近零或负值之间剧烈摆荡。"),
  bodyPara([
    run("与 DGTAP 平滑变化的网格大小／半宽曲面 [2，图一] 不同，即便套用了重置次数门槛，hedge_ratio／stepCycleAdd 曲面仍高度非单调（图一）：单一最佳格点 hedge_ratio\u2009=\u20090.6、stepCycleAdd\u2009=\u20090.005（Calmar 为 1.294），其相邻、hedge_ratio 相同的格点，分数却低于 0.1。我们将此视为与第五节 A、B 小节并列、值得报告的第三项独立缺陷：与 DGT 的网格大小维度不同，DHT 的对冲／加宽交互作用似乎并不具备宽广、平滑变化的最优区域，因此单一报告的“最佳”格点，作为建议参考时的稳健性也相对较低。一项稳健性检查——计算每个 hedge_ratio 在其非零 stepCycleAdd 相邻格点中的 Calmar 中位数——确实显示 hedge_ratio\u2009\u2208\u2009[0.5,\u20090.9] 是一个整体上表现较佳的区间（Calmar 中位数介于 0.35 至 0.64 之间），相对于两端极值（hedge_ratio\u2009=\u20090.0 或 1.0，Calmar 中位数约为 0.16 至 0.23）表现明显更佳，这也是我们采用 hedge_ratio\u2009=\u20090.6，而非将其视为孤立幸运格点的依据。"),
  ]),
  figureImage(M + "fig2_dht_widening_schedule.png", 1240, 800),
  figCaption("图二。在所采用的 stepCycleAdd = 0.005 下的网格间距加宽排程：间距随大循环内的循环加仓次数呈温和线性增长。"),
  subHeading("D", "主要操作点结果"),
  tableCaption("表二", "网格 2.5%／m=6，hedge_ratio=0.6，stepCycleAdd=0.005，资金费率=年化+10%"),
  makeTable(
    ["策略", "IRR", "MDD", "Calmar"],
    [
      ["买入并持有", "25.93%", "\u221277.54%", "0.334"],
      ["DGT（[1] 之基准）", "20.20%", "\u221246.29%", "0.436"],
      ["DHT（本文）", "29.74%", "\u221222.99%", "1.294"],
    ],
    [1900, 900, 900, 900]
  ),
  figureImage(M + "fig3_dht_equity_curves.png", 1300, 800),
  figCaption("图三。按市值计价权益曲线，按日重新取样，BTC/USD，2021年1月至2024年7月。DHT 在 2021 年至 2022 年初紧贴 DGT 走势，随后明显避开 DGT 在 2022 年最深的回撤，同时在 2023 至 2024 年的复苏行情中持续复利增长。"),
  bodyPara([
    run("在此操作点下，DHT 的报酬率同时优于买入并持有（IRR 为 29.74% 对 25.93%），且回撤幅度几乎为 DGT 的一半（−23.0% 对 −46.3%），相对于 DGT 基准，Calmar 比率提升了约三倍。样本期间共发生 25 次循环加仓事件，涵盖 16 个完整的大循环；此操作点下未触发任何对冲部位强制平仓。"),
  ]),
  subHeading("E", "对资金费率假设的敏感度"),
  bodyPara([
    run("如同 [2] 处理买权覆盖层波动率比值假设的方式，我们并未将假设的资金费率视为一个固定、不容质疑的输入值。图四针对表二的固定操作点，对假设的年化资金费率进行了扫描分析。"),
  ]),
  figureImage(M + "fig4_dht_funding_sensitivity.png", 1240, 800),
  figCaption("图四。Calmar 比率随假设年化资金费率变化的函数关系，hedge_ratio=0.6，stepCycleAdd=0.005。约在年化 +7% 至 8% 处存在体制转换；低于此门槛时，DHT 的表现与 DGT 基准（虚线）相当或更差。"),
  bodyPara([
    run("此结果对假设高度敏感：DHT 相对于 DGT 的 Calmar 优势，集中在约年化 +7% 至 8% 以上的资金费率体制，这与 [4]、[5] 所记载的历史上典型但非普遍存在的正资金费率情形一致。低于此门槛——包括真实市场压力期间确实会出现的零资金费率与负资金费率情形——DHT 的 Calmar 比率会降至 0.00 至 0.45 之间，与未对冲的 DGT 基准（0.436）相当或更差。我们之所以采用年化 +10% 作为本文的主要假设，是因为它落在历史文献记载的典型区间之内，而非区间边缘 [4]、[5]；但我们完整报告图四的全貌，而非仅呈现最有利的单点估计值，并将资金费率风险视为 DHT 最重要的开放性假设，其性质与 DGTAP 尚未解决的隐含／实现波动率比值假设直接类似。"),
  ]),
  subHeading("F", "对K棒取样频率的稳健性"),
  bodyPara([
    run("作为一项独立检验——相同资产、相同时间窗口，仅改变K棒取样频率——我们将表二的操作点套用于来自同一数据源的小时线重新取样 BTC/USD 数据（共 31,369 根K棒）进行重跑。结果并未顺利转移：DHT 的 Calmar 比率降至 0.178，而 DGT 本身在小时线上的 Calmar 比率为 0.175——两者实质上打平，并未展现出原生一分钟数据上所见的明显改善。针对小时线数据对 hedge_ratio 与 stepCycleAdd 进行完整重新扫描，显示小时线解析度下仍存在表现良好的格点（例如 hedge_ratio\u2009=\u20090.7、stepCycleAdd\u2009=\u20090.02 达到 Calmar 1.072），但这些格点与一分钟数据的最优点并不相同，且小时线曲面的非单调程度至少与一分钟曲面相当。我们将此解读为过拟合警讯，而非机制失效：在重新调校操作点的前提下，“对冲式循环加仓可优于原始 DGT”这项定性结论在小时线解析度下依然成立，但表二所报告的具体参数数值，是与用以找出它们的一分钟取样频率绑定的，不应假设可直接套用至不同的执行或再平衡节奏。"),
  ]),
  tableCaption("表三", "第五节所测试的参数范围"),
  makeTable(
    ["参数", "测试范围", "所选值"],
    [
      ["网格大小 k（7个离散值）", "1.0% \u2013 5.0%", "2.5%"],
      ["半宽 m", "4 \u2013 8", "6"],
      ["hedge_ratio", "0.0 \u2013 1.0", "0.6"],
      ["stepCycleAdd", "0 \u2013 0.03", "0.005"],
      ["资金费率（年化）", "\u221210% \u2013 +15%", "+10%（主要假设）"],
    ],
    [2500, 1250, 950]
  ),
  bodyPara([
    run("网格大小与半宽并未针对 DHT 本身重新优化；上表所报告的是在原生一分钟数据与小时线数据上（第五节 F 小节）以原始 DGT 程式路径重新检查的 7×5 离散网格，确认 k\u2009=\u20092.5%、m\u2009=\u20096——即 [2，表五] 中为 DGT 找出的 Calmar 最优操作点——在叠加 DHT 对冲机制之前仍属合理选择。对冲部位强制平仓上限（方程式 7）在整个研究过程中固定为名目金额的 50%，本身并未被纳入搜索范围。", { size: 18 }),
  ]),
];

// ============================================================
// 第六节 讨论与限制
// ============================================================
const sectionVI = [
  sectionHeading("讨论与限制", "VI"),
  subHeading("A", "单一资产、单一时间窗口的评估"),
  bodyPara([
    run("如同 [2]，本文所有结果仅采用 BTC/USD，且仅涵盖单一历史时期。受限于本研究的条件，未能取得解析度可比拟的真实 ETH 数据；我们认为，在将所报告的 hedge_ratio／stepCycleAdd 数值视为已定案的建议之前，针对 ETH 的验证，以及跨多个不重叠历史时间窗口的验证，皆属必要前提，尤其考量到即便在共同的 GARCH 族框架下，BTC 与 ETH 之间在波动率聚集与不对称性方面仍记录有差异 [2，第六节]。"),
  ]),
  subHeading("B", "资金费率风险是核心的开放性假设"),
  bodyPara([
    run("第五节 E 小节显示，DHT 的主要结果取决于一个历史上常见、但并非普遍存在且无法保证持续的资金费率体制 [4]、[5]。若要实际部署，须将此视为一项真实、须计价的风险来接受——如同任何空头carry策略都须承担资金费率／借贷成本风险——或依据已实现／预测的资金费率动态调整对冲部位规模或暂停对冲，而本文并未尝试后者。我们认为这与 DGTAP 尚未解决的、其买权覆盖层所依赖的隐含／实现波动率比值假设直接类似，且同样未获解决 [2，第五节 E 小节、第六节]。"),
  ]),
  subHeading("C", "简化的保证金与执行模型"),
  bodyPara([
    run("名目金额 50% 的强制平仓上限（方程式 7）只是对真实全仓／逐仓保证金与标记价格机制的粗略替代，真实机制还包括部分强制平仓、保险基金，以及交易所层级实证研究中所记载的强制平仓价格滑价 [8]。对冲部位除资金费率与价格损益外，未计入任何价差、滑价或额外的交易所手续费。这两项简化都使报告结果偏向对 DHT 有利，在任何实际部署前都应加以收紧。"),
  ]),
  subHeading("D", "对冲参数选择中的过拟合风险"),
  bodyPara([
    run("第五节 C 小节记录了 DHT 的 hedge_ratio／stepCycleAdd 曲面，即便套用了类似的重置次数门槛，仍明显比 DGT 自身的网格大小曲面更不平滑。报告单一“最佳”格点（表二）比 DGTAP 在其网格参数上做出的同类选择，更严重地低估了这种不稳定性；第五节 C 小节的邻域中位数稳健性检查，只是一种启发式的部分缓解措施，而非真正的解决方案，更完整的处理方式应套用回测过拟合文献中更广泛使用的、以长度正规化及重采样为基础的校正方法 [9]、[10]。"),
  ]),
  subHeading("E", "与 DGTAP 节流阀加买权方法的关系"),
  bodyPara([
    run("DHT 与 DGTAP 处理的是同一个根本问题——DGT 在持续下跌趋势中集中风险的倾向——但采用了结构上截然不同的机制：DGTAP 缩减每次买入的"),
    italicRun("规模"), run("，并另外购买会衰减的凸性保护部位；DHT 则附加一个不会衰减、持续按市值计价的空头部位，其规模依据"), italicRun("累积"),
    run("现货部位建构而成。这两种方法并非互斥：未来研究的一个自然方向，是评估结合 DGT＋节流阀＋对冲的综合变体，检验节流阀不依赖额外假设的回撤改善效果，与 DHT 依赖资金费率carry的改善效果，在同一样本上究竟是相加组合，抑或是相互替代。"),
  ]),
];

// ============================================================
// 第七节 结论
// ============================================================
const sectionVII = [
  sectionHeading("结论", "VII"),
  bodyPara([
    run("本文建立在 [1] 的 DGT 机制之上，并与我们先前的 DGTAP 扩展 [2] 在结构上有所区别，提出了动态对冲网格交易（DHT）：将一个反向永续期货对冲部位直接层叠于 DGT 的向下突破循环加仓事件之中，每次循环加仓皆针对累积的全部现货部位重新计算，并搭配每次循环加仓的网格加宽排程。在 3.5 年的真实比特币分钟级数据上，于经重置次数约束搜索所选定的操作点（hedge_ratio\u2009=\u20090.6，stepCycleAdd\u2009=\u20090.005）下，DHT 将 Calmar 比率由 DGT 的 0.436 提升至 1.294，同时提高了 IRR 并将最大回撤降低约一半。这项结果确实是有条件的，而非无条件成立：它实质上取决于一个假设中有利的资金费率体制（第五节 E 小节）、一个已证实远比 DGT 自身网格大小曲面更不平滑的对冲参数曲面（第五节 C 小节），且在未经重新调校的情况下，无法顺利转移至不同的K棒取样频率（第五节 F 小节）。我们也记录了两项实作上的缺陷——一个退化的全局出场条件，以及一个可能产生不可能出现的负权益的未设保证金对冲机制——并说明各自采用的修正方法，延续了 [2] 所建立的明确揭露不确定性与缺陷的精神。我们认为，对这三项开放性敏感度以及两项实作缺陷的诚实描述，与本文的主要点估计结果本身，同样具有价值。未来研究应针对 ETH 与多个不重叠的历史时间窗口验证本文提出的操作点，以正式估计的最小方差对冲比率 [7] 取代固定的 hedge_ratio，直接评估结合 DHT 与节流阀的变体相对于 DGTAP 的表现，并使用 [9] 的收缩夏普比率方法，针对报告的 Calmar 改善幅度，检验其相对于重采样或自助法（bootstrap）虚无假设的统计显著性。"),
  ]),
];

// ============================================================
// 参考文献
// ============================================================
const references = [
  new Paragraph({
    children: [boldRun("参考文献", { size: 21 })],
    spacing: { before: 240, after: 120 },
  }),
  refPara("[1] K.-Y. Chen, K.-H. Chen, and J.-S. R. Jang, \u201cDynamic Grid Trading Strategy: From Zero Expectation to Market Outperformance,\u201d arXiv preprint arXiv:2506.11921, 2025."),
  refPara("[2] [Authors], \u201cDynamic Grid Trading with Anti-Martingale Sizing and Protective Options: An Extension Toward Bounded Tail Risk,\u201d unpublished manuscript, 2026."),
  refPara("[3] A. Schmeling, A. Schrimpf, and K. Todorov, \u201cCrypto Carry,\u201d BIS Working Papers, no. 1087, 2023."),
  refPara("[4] K. Alexander, D. Choi, and A. Park, \u201cThe Economics of Cryptocurrency Perpetual Futures Funding Rates,\u201d working paper, 2022."),
  refPara("[5] C. Alexander, D. Deng, and Y. Feng, \u201cSystemic Risk in Cryptocurrency Perpetual Futures Markets,\u201d working paper, 2023."),
  refPara("[6] J. C. Hull, Options, Futures, and Other Derivatives, 10th ed. Boston: Pearson, 2018, ch. 3."),
  refPara("[7] L. L. Johnson, \u201cThe Theory of Hedging and Speculation in Commodity Futures,\u201d Review of Economic Studies, vol. 27, no. 3, pp. 139\u2013151, 1960."),
  refPara("[8] Y. Chen, Y. Ma, and B. Zheng, \u201cLiquidation Cascades in Cryptocurrency Perpetual Futures Markets,\u201d working paper, 2023."),
  refPara("[9] D. H. Bailey and M. L\u00f3pez de Prado, \u201cThe Deflated Sharpe Ratio: Correcting for Selection Bias, Backtest Overfitting, and Non-Normality,\u201d Journal of Portfolio Management, vol. 40, no. 5, pp. 94\u2013107, 2014."),
  refPara("[10] D. H. Bailey, J. Borwein, M. L\u00f3pez de Prado, and Q. J. Zhu, \u201cThe Probability of Backtest Overfitting,\u201d Journal of Computational Finance, vol. 20, no. 4, pp. 39\u201369, 2017."),
];

// ============================================================
// 附录
// ============================================================
const appendix = [
  new Paragraph({
    children: [boldRun("附录 A", { size: 21 }), boldRun("　程式代码与可重现性", { size: 21 })],
    spacing: { before: 240, after: 120 },
  }),
  bodyPara([
    run("DHT 回测实作（网格引擎、循环加仓触发的对冲部位调整、资金费率计提，以及保证金强制平仓防护）以 Python 撰写（dht_backtest.py），并依据第四节所述的 Bitstamp 数据集执行，采用与 [2] 验证过的相同 DGT 基准程式路径。此实作依据 [1] 所发表的算法描述重现 DGT 机制，而非采用该论文所附的原始程式代码，因此本文报告的 DGT 基准数字（表二）应仅与本系列论文内报告的 DGT 数字比较 [2]，而不应视为对 [1] 本身绝对数字的精确重现。第五节所引用的所有参数扫描结果，包括第五节 F 小节的小时线稳健性检验与第五节 E 小节的资金费率敏感度分析，皆随附于程式代码释出版本中。"),
  ]),
];

// ============================================================
// 组装文件
// ============================================================
const doc = new Document({
  styles: {
    default: {
      document: { run: { font: { name: FONT_EN, eastAsia: FONT_CJK }, size: 20 } },
    },
  },
  sections: [
    {
      properties: {
        page: {
          size: { width: 12240, height: 15840 },
          margin: { top: 1080, right: 900, bottom: 1440, left: 900, header: 708, footer: 708, gutter: 0 },
        },
        type: SectionType.CONTINUOUS,
      },
      children: titleBlock,
    },
    {
      properties: {
        page: {
          size: { width: 12240, height: 15840 },
          margin: { top: 1080, right: 900, bottom: 1440, left: 900, header: 708, footer: 708, gutter: 0 },
        },
        column: { count: 2, space: 288 },
        type: SectionType.CONTINUOUS,
      },
      children: [
        ...sectionI,
        ...sectionII,
        ...sectionIII,
        ...sectionIV,
        ...sectionV,
        ...sectionVI,
        ...sectionVII,
        ...references,
        ...appendix,
      ],
    },
  ],
});

Packer.toBuffer(doc).then(buffer => {
  fs.writeFileSync("DHT_IEEE_zh-CN.docx", buffer);
  console.log("Written DHT_IEEE_zh-CN.docx");
});
