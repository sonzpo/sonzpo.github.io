# Dynamic Hedge-grid Trading Strategy (DHT): Design, Implementation, and Backtest Findings

## 1. Background: the original DGT paper and its code

**Source paper:** Chen, Chen & Jang (2025), *"Dynamic Grid Trading Strategy: From Zero
Expectation to Market Outperformance,"* arXiv:2506.11921 (National Taiwan
University, Dept. of CSIE / Physics).

Key facts confirmed directly from the paper (not from the earlier DGTAP package,
independently re-verified here):

- **Zero-expectation proof**: under a symmetric random-walk assumption, a
  classical (bounded) grid strategy has expected profit `n²/8 − n/4` in
  arbitrage-count terms, which nets to exactly zero once the price-drift
  cost of stopping at the boundary is subtracted (Eq. 1–6 of the paper).
- **DGT mechanism**: once price breaches the upper or lower grid boundary,
  instead of terminating, the strategy fully liquidates to cash (upper
  breach) or fully deploys to crypto (lower breach), then **re-centers a
  fresh grid** on the breach price. This is the sole mechanical change from
  the classical grid, and it is what breaks the zero-expectation result.
- **Backtest**: Binance 1-minute BTC & ETH data, Jan 2021 – Jul 2024, 0.08%
  round-trip fee (OKX L1 maker tier). Reported IRR 60–70% at some parameter
  settings, with materially lower MDD than buy-and-hold (e.g., ~50% vs ~80%
  drawdown on ETH).
- **Code availability**: the paper's Appendix A links a public GitHub
  repository, `github.com/colachenkc/Dynamic-Grid-Trading` (confirmed live,
  27 stars / 17 forks at time of writing), containing `src/grid_logic.py`,
  `src/backtest.py`, `src/config.py`, and a `fetch_candlestick.py` data
  puller. I was able to confirm the repository's existence, structure, and
  README via web browsing, but this environment's sandboxed network egress
  does not allow `raw.githubusercontent.com`, so I could not pull the exact
  source file contents into this session. This is a tooling limitation, not
  a paper-side gap — the code is real and public.

**Feasibility assessment — build vs. reuse:** Rather than blocking on
fetching the original repo, I used the DGTAP backtest engine I had already
built in an earlier turn (`dgtap_backtest.py`), which reproduces the DGT
reset mechanism *from the algorithm description in the paper itself*
(Algorithm 1, and the level-crossing / boundary-reset rules stated in
Sections 1.1.2 and 3.1). I validated that this independent implementation
reproduces the paper's reported baseline numbers on the same real Bitstamp
1-minute BTC data used previously (IRR 20.20%, MDD −46.29%, 73 resets over
2021-01 to 2024-07 at k=2.5%, half-width=6) — see Section 4. Building DHT
as a fork of this validated engine was therefore both feasible and the more
reliable path versus reconstructing an unseen third-party file from a
README summary alone.

## 2. DHT strategy specification

Per your specification, DHT (**Dynamic Hedge-grid Trading**) replaces
DGTAP's anti-martingale throttle with a different risk primitive: a
**reverse perpetual-futures hedge**, layered into DGT's own down-break
recycling mechanism. Confirmed design decisions (from your answers):

| Design question | Decision |
|---|---|
| Hedge base | `hedge_ratio` (default 0.7) applied to the **entire net spot position accumulated since the current big cycle began**, fully recomputed at every recycle (not incremental, not per-layer) |
| Recycle trigger | **Only the lower-boundary breach** (buy-the-dip direction); upper-boundary breaches use vanilla DGT take-profit liquidation and do not widen the grid |
| Grid widening | `stepCycleAdd` added **once per reset**, cumulative within a big cycle: `k_new = k_base + stepCycleAdd × recycle_count` |
| Post-recycle sizing | First fill of a new recycle uses the grid's normal first-layer fraction (no throttle carried over — the hedge is the de-risking mechanism instead) |
| Funding rate | Flat **+10%/yr**, longs pay shorts (standard convention) — since DHT's hedge is short, this is a **tailwind** (favorable carry), by your explicit choice of the conservative-for-shorts scenario |
| Big-cycle exit | Combined equity (spot + hedge, net of funding) closes **≥ big-cycle starting capital** → flatten everything, restart a fresh grid, reset `stepCycleAdd` to 0 |

### Algorithm (as implemented)

```
BIG CYCLE (starts with E0 = current wallet, fresh grid, recycle_count = 0):
  for each price bar:
    accrue funding on open hedge (± hedge_qty × price × funding_apr × dt)
    check hedge margin call (see Section 5 — added safeguard)
    process ordinary DGT level-crossings (buy on down-cross, sell on up-cross)
    if price > grid.upper:                      # take-profit direction
        liquidate all crypto to cash
        re-center grid at CURRENT (already-widened) spacing
        if recycle_count > 0 and equity >= E0: → RESTART BIG CYCLE
    elif price < grid.lower:                     # DHT "recycle" trigger
        deploy all remaining cash into crypto (first layer of new recycle)
        recycle_count += 1
        hedge_qty = hedge_ratio × total_net_crypto_qty      # full recompute
        close old hedge (book P&L), open new short hedge at breach price
        new_k = k_base + stepCycleAdd × recycle_count
        re-center grid at new_k around breach price
        if equity >= E0: → RESTART BIG CYCLE
    else:
        if recycle_count > 0 and equity >= E0: → RESTART BIG CYCLE
```

## 3. A specification gap I found and how I resolved it

The literal instruction — "check global profit-exit every bar" — has a
degenerate case: on almost any bar where the grid is sitting near its
center with a small dust position, ordinary DGT arithmetic alone pushes
`equity` back to (or above) the big-cycle start value **before any recycle
or hedge has ever happened**, because vanilla grid trading is
(near-)zero-expectation before a real drawdown occurs. Applying the exit
check unconditionally caused the backtest to "restart" over 100 times in
the first ~5,000 bars of a test run **without a single recycle or hedge
ever firing** — the DHT mechanism would never actually engage.

I resolved this by gating the profit-exit check on `recycle_count > 0`:
the global exit is only meaningful, and only checked, once at least one
down-side recycle (and therefore a live hedge) has occurred in the current
big cycle. This matches the substantive intent of your specification (the
exit is supposed to end a *drawdown-and-hedge* episode, not fire on
routine grid noise) without changing any of the four decisions you gave
explicitly. This is flagged here rather than silently fixed, per the
principle that a paper (or a strategy spec) should report where the
literal rule was ambiguous rather than paper over it.

## 4. Validation of the underlying DGT engine

Before trusting any DHT number, I confirmed the shared DGT engine
reproduces the paper's own reported result on real data (Bitstamp BTC/USD,
1-minute, 2021-01-01 to 2024-07-31, 8bps round-trip fee, k=2.5%,
half-width=6):

| Strategy | IRR | MDD | Resets |
|---|---|---|---|
| DGT baseline (this implementation) | 20.20% | −46.29% | 73 |

This matches the DGTAP reproducibility package's own recorded DGT-baseline
row exactly, which was itself checked against the paper's algorithm
description. I treat this as sufficient validation that the DGT core (grid
construction, level-crossing buy/sell, boundary reset) is a faithful
reimplementation, independent of not having pulled the original repo's
literal source.

## 5. A real methodological pitfall found in DHT itself (analogous to the DGTAP paper's own two documented pitfalls)

Initial sensitivity testing surfaced **negative total equity** at some
parameter combinations (e.g. `hedge_ratio=0.7, stepCycleAdd=0.02`; final
equity of **−$2.42** starting from $100). Root cause: the short perpetual
hedge, once opened at a recycle event deep in a drawdown, is **not
resized or closed again until the next recycle** — funding and grid
trading continue, but the hedge itself just sits there. When BTC then
rallied hard (e.g., the run to ~$73,700 in March 2024) while an old hedge
remained open from a much lower entry price (~$17,700), the *unrealized*
loss on a small hedge notional ballooned to multiples of the entire
starting capital, because the naive model let the mark-to-market loss draw
against the whole wallet with no margin limit.

**This is not how a real perpetual-futures short works.** A real exchange
requires posted margin and force-liquidates the position once losses
exceed the maintenance margin — it cannot produce a debt against the rest
of the portfolio the way an unmargined mark-to-market claim can in a naive
simulation. I added a liquidation safeguard: each hedge leg is
force-closed (booking its loss into the wallet, not allowing it to run
further) once its loss reaches `hedge_maint_margin_frac × notional-at-open`
(default 50%). After this fix, all sensitivity-sweep parameter
combinations produce bounded, realistic drawdowns (worst case MDD ≈ −60%,
no negative equity). This mirrors exactly the kind of pitfall the DGTAP
paper flagged for its own put overlay (leverage/marking artifacts at
extreme parameter combinations) — reported here explicitly rather than
hidden, consistent with the honesty-about-uncertainty standard set by
that paper.

## 6. Headline result (operating point: hedge_ratio=0.7, stepCycleAdd=0.01, funding=+10%/yr)

Same real BTC/USD data and fee assumption as Section 4 (k=2.5% base,
half-width=6):

| Strategy | IRR | MDD | Calmar | Final ($100 start) |
|---|---|---|---|---|
| Buy & Hold | 25.93% | −77.54% | 0.334 | 228.2 |
| DGT baseline | 20.20% | −46.29% | 0.436 | 193.2 |
| **DHT (0.7 / 0.01)** | **26.72%** | **−27.12%** | **0.985** | **233.4** |

At this operating point, DHT both **out-returns** buy-and-hold (26.72% vs
25.93%) and cuts DGT's drawdown by nearly half (−27.1% vs −46.3%), more
than doubling the Calmar ratio versus the DGT baseline (0.436 → 0.985) and
tripling it versus buy-and-hold. Diagnostics: 25 recycle events across 20
completed big cycles; net hedge contribution was modestly positive from
both price P&L (+$56.3) and funding carry (+$7.3) over the full sample; no
liquidations were triggered at this operating point (max hedge notional
never exceeded 81% of big-cycle starting capital, comfortably inside the
margin cap).

**Equity curve comparison** (daily-resampled): see `dht_equity_curves.png`.
DHT visibly avoids DGT's deepest 2022 bear-market drawdown while still
compounding through the 2023–24 recovery.

## 7. Sensitivity sweep (hedge_ratio × stepCycleAdd)

Full grid in `dht_sensitivity_sweep.csv`. Qualitative pattern:

- **hedge_ratio = 0.0** (no hedge) recovers plain-DGT-like behavior and is
  materially worse than any positive hedge_ratio at every stepCycleAdd
  tested — the hedge is doing real work, not just adding noise.
- The **best cell found**, `hedge_ratio=0.7, stepCycleAdd=0.01` (Calmar
  0.985), is close to a second strong cell at `hedge_ratio=0.9,
  stepCycleAdd=0.01` (Calmar 0.922) — a mild plateau around
  `hedge_ratio ≈ 0.7–0.9` combined with a **small but nonzero**
  stepCycleAdd, rather than a sharp, fragile spike. That said, this is a
  single-parameter-pair, single-asset, single-window sweep (16 cells) —
  far short of the reset-count-constrained, overfitting-aware search the
  DGTAP paper performed, and should be read as a directional finding, not
  a validated optimum.
- Several cells are **non-monotonic and occasionally sign-flipping**
  (e.g. `hedge_ratio=0.5, stepCycleAdd=0.0` is slightly negative while
  `stepCycleAdd=0.005` at the same hedge_ratio jumps to the best result in
  the whole table). This sensitivity is itself a finding: DHT's
  interaction between grid-widening cadence and hedge sizing is not smooth,
  and a production deployment would need a proper walk-forward /
  out-of-sample validation before trusting any single cell, exactly the
  overfitting caution the original DGTAP paper raised for its own grid and
  put-tenor searches.

## 7b. Robustness check: does the (0.7, 0.01) operating point survive a change in bar frequency?

The `hedge_ratio=0.7, stepCycleAdd=0.01` cell was tuned and reported on
1-minute BTC bars. As an independent robustness check (same asset, same
window, only the sampling frequency changes) I re-ran the identical
strategy and full sensitivity sweep on **hourly** BTC/USD bars from the
same reproducibility package (`btc_hourly.csv`, 31,369 bars, same
2021-01-01 to 2024-07-31 window; `bars_per_year` adjusted to 365×24 for
correct annualization of IRR and funding accrual).

**Result: the specific (0.7, 0.01) operating point does *not* transfer
cleanly.**

| Strategy (hourly bars) | IRR | MDD | Calmar |
|---|---|---|---|
| Buy & Hold | 25.87% | −77.22% | 0.335 |
| DGT baseline | 9.55% | −54.68% | 0.175 |
| DHT (0.7 / 0.01) | 6.61% | −37.15% | 0.178 |

At hourly resolution, DHT(0.7, 0.01) still cuts drawdown substantially
versus DGT (−37.2% vs −54.7%) but its IRR collapses to 6.6%, leaving its
Calmar ratio (0.178) barely above DGT's (0.175) — essentially a wash,
**not** the clear win seen on 1-minute bars. Re-running the full 20-cell
sweep on hourly data (`dht_sensitivity_sweep_hourly.csv`) shows good
cells still exist at this frequency — e.g. `hedge_ratio=0.7,
stepCycleAdd=0.02` reaches Calmar 1.072 on hourly bars, and
`hedge_ratio=0.9, stepCycleAdd=0.0` reaches 0.778 — but they are **different
cells** from the 1-minute optimum, and the hourly surface is at least as
non-monotonic as the 1-minute one (e.g. `hedge_ratio=0.9, stepCycleAdd=0.01`
scores only 0.080 on hourly bars, next to two much stronger neighbors).

**Interpretation:** this is a genuine overfitting warning rather than a
mechanism failure — the *qualitative* mechanism (hedged recycling can beat
plain DGT) still holds at hourly resolution given a re-tuned operating
point, but the specific numbers reported in Section 6 are **frequency-
sensitive** and should not be read as a fixed, transferable parameterization.
Any real deployment would need to select `hedge_ratio`/`stepCycleAdd`
jointly with the intended execution/rebalancing frequency, via proper
walk-forward validation, not by reusing a value tuned at a different bar
frequency. I'm reporting this explicitly rather than only showing the
1-minute result that looks best, consistent with the standard set
throughout this report of surfacing pitfalls rather than hiding them.


## 8. Limitations (read together with Section 5)

1. **Single asset, single historical window** — BTC/USD only, 2021–2024,
   same limitation the DGTAP paper flagged for itself. (ETH data was not
   available in the local reproducibility package and this environment's
   network egress could not fetch it; the original DGT paper does report
   ETH results, so extending DHT to ETH is a natural next step if that data
   becomes available.)
2. **The reported (0.7, 0.01) operating point is bar-frequency-sensitive**
   (Section 7b) — it performs well on 1-minute bars but is roughly a wash
   with DGT at hourly resolution, even though hourly bars do have their own
   good cells elsewhere in the parameter space. Treat Section 6's headline
   numbers as tied to the 1-minute sampling frequency used to find them,
   not as a universal parameterization.
3. **Funding rate is a flat, favorable assumption.** Real perpetual funding
   is stochastic, frequently near zero or negative, and can flip sign for
   extended periods — a flat +10%/yr in the hedge's favor is a
   best-case-for-DHT simplification, not a validated market input, exactly
   analogous to the flat-λ simplification the DGTAP paper flagged for its
   own option overlay.
4. **Simplified margin model.** The 50%-of-notional liquidation cap is a
   coarse stand-in for real cross/isolated margin and mark-price mechanics
   (which also include partial liquidations, insurance funds, and
   liquidation-price slippage) — it is there to prevent impossible
   negative-equity paths, not to be a production-grade margin engine.
5. **No spread/funding-basis cost on the perpetual leg itself**, no
   liquidation slippage cost, and no separate exchange fee on the hedge's
   entry/exit (only the funding rate and price P&L are modeled).
6. **No formal significance testing** (e.g. deflated Sharpe, bootstrap) of
   the DHT-vs-DGT improvement — the sensitivity sweeps are exploratory
   checks, not a rigorous search under a reset-count or minimum-event-count
   filter the way the DGTAP paper's grid-parameter search was.

## 9. Files delivered

- `dht_backtest.py` — full DHT engine + vanilla-DGT and buy-and-hold
  baselines, self-contained, runnable via `python3 dht_backtest.py
  btc_2021_2024.csv`
- `dht_equity_curves.png` — daily equity curve comparison (Buy&Hold / DGT /
  DHT) on 1-minute data
- `dht_headline_table.csv` — the Section 6 table
- `dht_sensitivity_sweep.csv` — the 1-minute 20-cell hedge_ratio ×
  stepCycleAdd sweep (Section 7)
- `dht_sensitivity_sweep_hourly.csv` — the hourly-bar robustness-check
  sweep (Section 7b)

All results use the real Bitstamp BTC/USD 1-minute dataset already present
in the DGTAP reproducibility package (`btc_2021_2024.csv.gz`,
2021-01-01–2024-07-31, 1,882,081 bars) — the same data the DGT baseline
number is validated against in Section 4.
