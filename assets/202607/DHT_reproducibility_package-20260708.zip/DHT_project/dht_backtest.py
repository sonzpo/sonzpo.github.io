"""
DHT: Dynamic Hedge-grid Trading Strategy
=========================================

An independent extension of DGT (Chen, Chen & Jang, 2025, arXiv:2506.11921)
that replaces DGTAP's anti-martingale throttle + OTM-put overlay with a
different risk-management primitive: a **reverse perpetual-futures hedge**
layered into the grid's own down-break recycling mechanism.

DESIGN (as specified by the user, "DHT" = Dynamic Hedge-grid Trading):

  Big cycle
  ---------
  A "big cycle" starts with starting equity E0 (spot wallet, all cash) and a
  fresh grid centered on the current price, stepCycleAdd-offset reset to 0.
  The big cycle ends and restarts (fresh grid, stepCycleAdd reset to 0, hedge
  flattened) the first time combined equity (spot + perp hedge P&L, net of
  funding) closes back >= E0. This is the "global profit exit, restart"
  condition.

  Recycle layer (only triggered on DOWN-side grid breaches, i.e. price
  breaking below the grid's lower boundary -- DGT's "buy-the-dip" boundary,
  NOT the upper/take-profit boundary)
  -----------------------------------------------------------------------
  On a lower-boundary breach:
    1. All remaining USDT is deployed into spot at the breach price (as in
       vanilla DGT's lower-boundary rule) -- this is the recycle's "first
       position, first layer".
    2. Immediately after that fill, the hedge is (re)computed: close the old
       short-perp hedge (settle its P&L + funding into the spot wallet) and
       open a new short-perp hedge sized at:
           hedge_notional_qty = hedge_ratio * total_net_spot_qty_held
       i.e. hedge_ratio (default 0.7) is applied to the ENTIRE net spot
       position accumulated since the big cycle began, recomputed fresh at
       every recycle event (not just the newly-added layer).
    3. A new grid is re-centered on the breach price. Grid spacing k for
       the NEW grid is the ORIGINAL k plus stepCycleAdd, multiplied by the
       number of recycles that have occurred in the current big cycle so
       far (k_new = k_base + stepCycleAdd * recycle_count) -- i.e. it grows
       by one increment per reset event, exactly as specified ("each reset
       only adds once, widening grid spacing").
    4. Buy-side sizing within the new grid restarts at the grid's first-layer
       fraction (1/half_n), i.e. the throttle/consecutive-fill counter used
       by DGTAP is NOT used here -- DHT substitutes the hedge for that
       de-risking role, so buy-side sizing is the vanilla DGT rule applied
       to the freshly-widened grid.

  Upper-boundary breaches (take-profit direction) are handled exactly as in
  vanilla DGT: full liquidation of crypto back to cash, and this liquidation
  event is also treated as a global equity update (it can itself trigger the
  big-cycle profit-exit check).

  Perpetual hedge P&L and funding
  --------------------------------
  The hedge is a SHORT perpetual future on the same underlying, notional
  hedge_notional_qty units, mark-to-market against spot price. Funding is
  charged/credited every bar using an assumed constant ANNUALIZED funding
  rate (default +10%, i.e. longs pay shorts 10%/yr under the standard
  convention that positive funding = longs pay shorts). Since DHT's hedge
  is SHORT, a positive funding rate is a tailwind (the hedge collects
  funding while also paying off if price falls further) -- consistent with
  the user's specified "conservative-favorable" scenario.

  Funding accrues continuously against the CURRENT hedge notional (i.e. if
  hedge size changes at a recycle event, funding after that point uses the
  new size).

DISCLAIMER: research/backtesting tool only, not investment advice. Real
perpetual funding rates are stochastic and frequently flip sign; the flat
+10%/yr assumption here is a simplification, exactly as the DGTAP paper
flagged for its own put-overlay volatility assumption. This is NOT a
validated production strategy.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Optional

import numpy as np
import pandas as pd


# ---------------------------------------------------------------------------
# Grid construction (same geometric grid as DGT/DGTAP)
# ---------------------------------------------------------------------------

@dataclass
class Grid:
    center: float
    k: float
    half_n: int

    def levels(self) -> np.ndarray:
        idx = np.arange(-self.half_n, self.half_n + 1)
        return self.center * (1.0 + self.k) ** idx

    @property
    def upper(self) -> float:
        return self.center * (1.0 + self.k) ** self.half_n

    @property
    def lower(self) -> float:
        return self.center * (1.0 + self.k) ** (-self.half_n)


# ---------------------------------------------------------------------------
# DHT configuration
# ---------------------------------------------------------------------------

@dataclass
class DHTConfig:
    grid_size: float = 0.025          # base k (matches DGTAP paper's chosen operating point)
    half_n: int = 6
    principal: float = 100.0
    fee_pct: float = 0.0008
    hedge_ratio: float = 0.6          # fraction of TOTAL net spot qty hedged short, recomputed each recycle
    step_cycle_add: float = 0.005     # k widens by this much per recycle within a big cycle
    funding_apr: float = 0.10         # annualized funding rate; positive = longs pay shorts (favorable to DHT's short hedge)
    bars_per_year: float = 365 * 24 * 60
    hedge_maint_margin_frac: float = 0.5
    # Realistic guard: a real short-perp position is posted with margin and is
    # liquidated by the exchange once losses exceed that margin -- it cannot
    # draw the spot wallet down to an arbitrary negative number the way an
    # un-margined mark-to-market claim would. We model this simply: the
    # hedge's maximum tolerated loss before forced liquidation is
    # hedge_maint_margin_frac * (hedge notional at the time it was opened),
    # booked against the wallet at that point rather than allowed to run
    # further. This is a simplification of real cross/isolated margin
    # mechanics, but prevents the backtest from reporting impossible
    # negative-equity paths for a position no real exchange would leave open.


@dataclass
class DHTResult:
    equity_curve: pd.Series
    trades: int
    grid_resets: int
    recycle_events: int
    big_cycles: int
    final_equity: float
    irr: float
    mdd: float
    total_funding_pnl: float
    total_hedge_price_pnl: float
    max_hedge_notional_frac: float   # largest hedge notional as fraction of principal, sanity check
    hedge_liquidations: int = 0      # count of forced-liquidation events on the short hedge leg


class DHTStrategy:
    """Dynamic Hedge-grid Trading strategy."""

    def __init__(self, cfg: DHTConfig):
        self.cfg = cfg

    def run(self, prices: pd.Series) -> DHTResult:
        c = self.cfg
        p = prices.values.astype(float)
        n = len(p)
        dt_years = 1.0 / c.bars_per_year

        # --- state ---
        wallet_usdt = c.principal
        crypto_qty = 0.0

        big_cycle_start_equity = c.principal
        recycle_count_this_cycle = 0   # drives k widening
        big_cycles = 0
        recycle_events = 0
        grid_resets = 0
        trades = 0

        # short perp hedge state
        hedge_qty = 0.0             # units short (positive number = short size)
        hedge_entry_price = 0.0
        hedge_notional_at_open = 0.0  # $ notional when this hedge leg was opened, for margin cap
        hedge_realized_pnl = 0.0    # realized (booked at close/resize) price P&L, cumulative for reporting
        hedge_funding_pnl = 0.0     # cumulative funding P&L, for reporting
        total_funding_pnl = 0.0
        total_hedge_price_pnl = 0.0
        max_hedge_notional_frac = 0.0
        hedge_liquidations = 0

        grid = Grid(center=p[0], k=c.grid_size, half_n=c.half_n)
        levels = grid.levels()
        black_idx = c.half_n

        equity = np.empty(n)

        def spot_value(px: float) -> float:
            return wallet_usdt + crypto_qty * px

        def hedge_unrealized(px: float) -> float:
            # short position: profits when price falls below entry
            if hedge_qty <= 0:
                return 0.0
            return hedge_qty * (hedge_entry_price - px)

        def combined_equity(px: float) -> float:
            return spot_value(px) + hedge_unrealized(px)

        def close_hedge(px: float):
            """Settle the current hedge's unrealized P&L into the spot wallet and flatten it."""
            nonlocal wallet_usdt, hedge_qty, hedge_entry_price, hedge_notional_at_open
            nonlocal hedge_realized_pnl, total_hedge_price_pnl
            if hedge_qty > 0:
                pnl = hedge_unrealized(px)
                wallet_usdt += pnl
                hedge_realized_pnl += pnl
                total_hedge_price_pnl += pnl
            hedge_qty = 0.0
            hedge_entry_price = 0.0
            hedge_notional_at_open = 0.0

        def resize_hedge(px: float, target_qty: float):
            """Close existing hedge (booking its P&L) and open a fresh short of target_qty at px."""
            nonlocal hedge_qty, hedge_entry_price, hedge_notional_at_open
            close_hedge(px)
            if target_qty > 1e-12:
                hedge_qty = target_qty
                hedge_entry_price = px
                hedge_notional_at_open = target_qty * px

        def check_hedge_liquidation(px: float):
            """Force-close the hedge if its loss exceeds the maintenance-margin cap
            (a real exchange would have margin-called this position; an
            un-margined mark-to-market claim against the whole wallet is not a
            realistic model of a perpetual-futures hedge)."""
            nonlocal hedge_liquidations
            if hedge_qty <= 0:
                return
            loss = -hedge_unrealized(px)  # positive number = a loss
            cap = c.hedge_maint_margin_frac * hedge_notional_at_open
            if loss >= cap > 0:
                close_hedge(px)
                hedge_liquidations += 1

        def start_new_big_cycle(px: float):
            nonlocal big_cycle_start_equity, recycle_count_this_cycle, big_cycles
            nonlocal wallet_usdt, crypto_qty, grid, levels, black_idx
            # flatten hedge, sweep everything to cash, start fresh
            close_hedge(px)
            if crypto_qty > 0:
                wallet_usdt += crypto_qty * px * (1.0 - c.fee_pct)
                crypto_qty = 0.0
            big_cycle_start_equity = wallet_usdt
            recycle_count_this_cycle = 0
            big_cycles += 1
            grid = Grid(center=px, k=c.grid_size, half_n=c.half_n)
            levels = grid.levels()
            black_idx = c.half_n

        for i in range(n):
            px = p[i]

            # --- funding accrual on current hedge notional (applied once per bar) ---
            if hedge_qty > 0:
                funding_cashflow = hedge_qty * px * c.funding_apr * dt_years
                # positive funding_apr => longs pay shorts => hedge (short) COLLECTS funding
                wallet_usdt += funding_cashflow
                hedge_funding_pnl += funding_cashflow
                total_funding_pnl += funding_cashflow

            # --- margin check: liquidate the hedge if it has blown through its
            #     maintenance margin (see check_hedge_liquidation docstring) ---
            check_hedge_liquidation(px)

            # --- up-crossing: sell (vanilla DGT rule, unchanged by DHT) ---
            while black_idx < len(levels) - 1 and px >= levels[black_idx + 1]:
                black_idx += 1
                g_i = max(len(levels) - 1 - black_idx, 1)
                sell_frac = 1.0 / g_i
                sell_qty = crypto_qty * sell_frac
                if sell_qty > 0:
                    proceeds = sell_qty * px * (1.0 - c.fee_pct)
                    wallet_usdt += proceeds
                    crypto_qty -= sell_qty
                    trades += 1

            # --- down-crossing: buy (vanilla DGT rule; sizing uses CURRENT widened grid, no throttle) ---
            while black_idx > 0 and px <= levels[black_idx - 1]:
                black_idx -= 1
                g_j = max(black_idx + 1, 1)
                buy_frac = 1.0 / g_j
                spend = wallet_usdt * buy_frac
                if spend > 0:
                    qty = (spend * (1.0 - c.fee_pct)) / px
                    crypto_qty += qty
                    wallet_usdt -= spend
                    trades += 1

            # --- upper boundary breach: vanilla DGT take-profit reset ---
            if px > grid.upper:
                wallet_usdt += crypto_qty * px * (1.0 - c.fee_pct)
                crypto_qty = 0.0
                grid_resets += 1
                # re-center grid at current (base) spacing -- upper breach does not
                # widen spacing; only down-side recycles do, per spec.
                grid = Grid(center=px, k=c.grid_size + c.step_cycle_add * recycle_count_this_cycle,
                            half_n=c.half_n)
                levels = grid.levels()
                black_idx = c.half_n

                # global profit-exit check after this equity-changing event (only
                # meaningful once a recycle/hedge has occurred this big cycle --
                # see rationale in the flat-bar branch below)
                if recycle_count_this_cycle > 0 and combined_equity(px) >= big_cycle_start_equity:
                    start_new_big_cycle(px)

            # --- lower boundary breach: THIS is the DHT "recycle" trigger ---
            elif px < grid.lower:
                # 1) first layer of the new recycle: deploy all remaining cash into spot
                if wallet_usdt > 0:
                    qty = (wallet_usdt * (1.0 - c.fee_pct)) / px
                    crypto_qty += qty
                    wallet_usdt = 0.0
                    trades += 1

                grid_resets += 1
                recycle_events += 1
                recycle_count_this_cycle += 1

                # 2) recompute hedge on TOTAL net spot qty accumulated so far, at hedge_ratio
                target_hedge_qty = c.hedge_ratio * crypto_qty
                resize_hedge(px, target_hedge_qty)
                notional_frac = (target_hedge_qty * px) / max(big_cycle_start_equity, 1e-9)
                max_hedge_notional_frac = max(max_hedge_notional_frac, notional_frac)

                # 3) new grid, spacing widened by stepCycleAdd * recycle count (once per reset)
                new_k = c.grid_size + c.step_cycle_add * recycle_count_this_cycle
                grid = Grid(center=px, k=new_k, half_n=c.half_n)
                levels = grid.levels()
                black_idx = c.half_n
                # 4) buy-side sizing restarts at first-layer fraction automatically,
                #    since black_idx is reset to half_n (g_j = 1 on next down-crossing)

                # global profit-exit check (rare on a down-break, but checked for completeness)
                if combined_equity(px) >= big_cycle_start_equity:
                    start_new_big_cycle(px)

            else:
                # No grid boundary breach this bar. The "global profit exit" is only
                # meaningful once a recycle/hedge has actually been established in
                # this big cycle -- otherwise plain grid oscillation near the start
                # price trivially satisfies "equity >= E0" on almost every bar and
                # would restart the cycle before DHT's hedge mechanism ever engages.
                # We therefore gate the flat-bar exit check on recycle_count_this_cycle > 0
                # (i.e. at least one down-side recycle, and hence a live hedge, must
                # have occurred this big cycle before a profit-exit can fire).
                if recycle_count_this_cycle > 0 and combined_equity(px) >= big_cycle_start_equity:
                    start_new_big_cycle(px)

            equity[i] = combined_equity(px)

        eq = pd.Series(equity, index=prices.index)
        years = max((prices.index[-1] - prices.index[0]).total_seconds() / (365.25 * 24 * 3600), 1e-6)
        irr = (eq.iloc[-1] / c.principal) ** (1.0 / years) - 1.0
        running_max = eq.cummax()
        mdd = float(((eq - running_max) / running_max).min())

        return DHTResult(
            equity_curve=eq,
            trades=trades,
            grid_resets=grid_resets,
            recycle_events=recycle_events,
            big_cycles=big_cycles,
            final_equity=float(eq.iloc[-1]),
            irr=float(irr),
            mdd=mdd,
            total_funding_pnl=total_funding_pnl,
            total_hedge_price_pnl=total_hedge_price_pnl,
            max_hedge_notional_frac=max_hedge_notional_frac,
            hedge_liquidations=hedge_liquidations,
        )


# ---------------------------------------------------------------------------
# Baselines re-implemented locally (self-contained file; same logic as
# dgtap_backtest.py's DGT-only / DGT+throttle paths, for side-by-side compare)
# ---------------------------------------------------------------------------

@dataclass
class BaselineResult:
    equity_curve: pd.Series
    trades: int
    grid_resets: int
    final_equity: float
    irr: float
    mdd: float


def run_vanilla_dgt(prices: pd.Series, grid_size: float, half_n: int, principal: float, fee_pct: float) -> BaselineResult:
    p = prices.values.astype(float)
    n = len(p)
    wallet_usdt = principal
    crypto_qty = 0.0
    grid = Grid(center=p[0], k=grid_size, half_n=half_n)
    levels = grid.levels()
    black_idx = half_n
    trades = 0
    grid_resets = 0
    equity = np.empty(n)

    for i in range(n):
        px = p[i]
        while black_idx < len(levels) - 1 and px >= levels[black_idx + 1]:
            black_idx += 1
            g_i = max(len(levels) - 1 - black_idx, 1)
            sell_qty = crypto_qty / g_i
            if sell_qty > 0:
                wallet_usdt += sell_qty * px * (1.0 - fee_pct)
                crypto_qty -= sell_qty
                trades += 1
        while black_idx > 0 and px <= levels[black_idx - 1]:
            black_idx -= 1
            g_j = max(black_idx + 1, 1)
            spend = wallet_usdt / g_j
            if spend > 0:
                crypto_qty += (spend * (1.0 - fee_pct)) / px
                wallet_usdt -= spend
                trades += 1
        if px > grid.upper or px < grid.lower:
            if px > grid.upper:
                wallet_usdt += crypto_qty * px * (1.0 - fee_pct)
                crypto_qty = 0.0
            else:
                crypto_qty += (wallet_usdt * (1.0 - fee_pct)) / px
                wallet_usdt = 0.0
            grid = Grid(center=px, k=grid_size, half_n=half_n)
            levels = grid.levels()
            black_idx = half_n
            grid_resets += 1
        equity[i] = wallet_usdt + crypto_qty * px

    eq = pd.Series(equity, index=prices.index)
    years = max((prices.index[-1] - prices.index[0]).total_seconds() / (365.25 * 24 * 3600), 1e-6)
    irr = (eq.iloc[-1] / principal) ** (1.0 / years) - 1.0
    running_max = eq.cummax()
    mdd = float(((eq - running_max) / running_max).min())
    return BaselineResult(eq, trades, grid_resets, float(eq.iloc[-1]), float(irr), mdd)


def buy_and_hold(prices: pd.Series, principal: float) -> BaselineResult:
    qty = principal / prices.iloc[0]
    eq = qty * prices
    years = max((prices.index[-1] - prices.index[0]).total_seconds() / (365.25 * 24 * 3600), 1e-6)
    irr = (eq.iloc[-1] / principal) ** (1.0 / years) - 1.0
    running_max = eq.cummax()
    mdd = float(((eq - running_max) / running_max).min())
    return BaselineResult(eq, 0, 0, float(eq.iloc[-1]), float(irr), mdd)


def load_klines_csv(path: str, ts_col: str = "ts", price_col: str = "close") -> pd.Series:
    df = pd.read_csv(path)
    if ts_col not in df.columns:
        for c_ in ("timestamp", "time", "date", "datetime", "open_time"):
            if c_ in df.columns:
                ts_col = c_
                break
    ts = pd.to_datetime(df[ts_col], errors="coerce")
    if ts.isna().all():
        ts = pd.to_datetime(df[ts_col], unit="ms", errors="coerce")
    s = pd.Series(df[price_col].values, index=ts).dropna()
    return s.sort_index()


if __name__ == "__main__":
    import sys
    csv_path = sys.argv[1] if len(sys.argv) > 1 else "btc_2021_2024.csv"
    prices = load_klines_csv(csv_path)
    principal = 100.0

    bh = buy_and_hold(prices, principal)
    dgt = run_vanilla_dgt(prices, 0.025, 6, principal, 0.0008)
    dht = DHTStrategy(DHTConfig(grid_size=0.025, half_n=6, principal=principal,
                                 hedge_ratio=0.6, step_cycle_add=0.005,
                                 funding_apr=0.10)).run(prices)

    def calmar(irr, mdd):
        return irr / abs(mdd) if mdd != 0 else float("nan")

    print(f"Data: {len(prices)} bars, {prices.index[0]} -> {prices.index[-1]}\n")
    print(f"{'Strategy':28s}  {'IRR':>8s}   {'MDD':>8s}   {'Calmar':>7s}   {'Final':>10s}   {'Trades':>7s}   {'Resets':>6s}")
    print(f"{'Buy & Hold':28s}  {bh.irr*100:7.2f}%  {bh.mdd*100:7.2f}%   {calmar(bh.irr,bh.mdd):7.3f}   {bh.final_equity:10,.1f}")
    print(f"{'DGT baseline':28s}  {dgt.irr*100:7.2f}%  {dgt.mdd*100:7.2f}%   {calmar(dgt.irr,dgt.mdd):7.3f}   {dgt.final_equity:10,.1f}   {dgt.trades:7d}   {dgt.grid_resets:6d}")
    print(f"{'DHT (hedge_ratio=0.6)':28s}  {dht.irr*100:7.2f}%  {dht.mdd*100:7.2f}%   {calmar(dht.irr,dht.mdd):7.3f}   {dht.final_equity:10,.1f}   {dht.trades:7d}   {dht.grid_resets:6d}")
    print(f"\nDHT diagnostics: recycle_events={dht.recycle_events}  big_cycles={dht.big_cycles}  "
          f"funding_pnl={dht.total_funding_pnl:,.2f}  hedge_price_pnl={dht.total_hedge_price_pnl:,.2f}  "
          f"max_hedge_notional_frac={dht.max_hedge_notional_frac:.2f}x  hedge_liquidations={dht.hedge_liquidations}")
