const H = require("./helpers");
const { Document, Packer, Paragraph, TextRun, AlignmentType, SectionType,
  Header, Footer, PageNumber } = H;

// 中文本文改用左對齊，避免西方文書軟體對CJK文字進行兩端對齊時
// 產生不美觀的字距拉伸（尤其在標點符號改為全形後，換行位置改變，
// 兩端對齊會讓部分行的字元間距被拉得過寬）。
H.setDefaultAlign(AlignmentType.LEFT);

const { titleBlock, abstractBlock } = require("./part1_title_cn");
const { section1_intro } = require("./part2_intro_related_cn");
const { section3_method, section4_data } = require("./part3_method_data_cn");
const { section5_results } = require("./part4_results_cn");
const { section6_discussion, references, appendix } = require("./part5_discussion_refs_cn");

const allBodyChildren = [
  ...section1_intro,
  ...section3_method,
  ...section4_data,
  ...section5_results,
  ...section6_discussion,
  ...references,
  ...appendix,
];

const doc = new Document({
  sections: [
    {
      properties: {
        page: {
          size: { width: 12240, height: 15840 },
          margin: { top: 1080, right: 900, bottom: 1440, left: 900, header: 708, footer: 708 },
        },
      },
      children: titleBlock.concat(abstractBlock),
    },
    {
      properties: {
        type: SectionType.CONTINUOUS,
        page: {
          size: { width: 12240, height: 15840 },
          margin: { top: 1080, right: 900, bottom: 1440, left: 900, header: 708, footer: 708 },
        },
        column: { count: 2, space: 288 },
      },
      children: allBodyChildren,
    },
  ],
});

Packer.toBuffer(doc).then(buf => {
  require("fs").writeFileSync("DMT_paper_CN.docx", buf);
  console.log("written DMT_paper_CN.docx", buf.length, "bytes");
});
