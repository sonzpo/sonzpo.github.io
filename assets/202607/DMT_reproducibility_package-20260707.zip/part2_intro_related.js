const H = require("./helpers");
const { AlignmentType, p, run, heading1, heading2 } = H;

const section1_intro = [
  heading1("I", "Introduction"),
  p([run(
    "Grid trading places a ladder of buy and sell orders at geometrically spaced prices around a reference level and profits from round trips as price oscillates through the ladder. Chen, Chen, and Jang [1] showed that under a symmetric random-walk assumption a naive grid that terminates on reaching either boundary has exactly zero expected profit before fees \u2014 and negative expected profit after fees \u2014 and proposed Dynamic Grid Trading (DGT): instead of terminating, the grid re-centers on the current price when a boundary is breached, with an asymmetric rule (liquidate to cash on an upward breach; retain all held coin on a downward breach, funding the new grid's cash side only from previously banked arbitrage profit). This single asymmetry is what converts a zero-expectation mechanism into one that empirically outperformed buy-and-hold on real BTC and ETH data over 2021\u20132024."
  )]),
  p([run(
    "A companion report [2] (\u201cDGTAP\u201d) extended DGT along two structurally independent axes \u2014 an anti-martingale position throttle that de-risks consecutive down-fills, and a Black\u2013Scholes-priced out-of-the-money put overlay \u2014 and found the throttle to be the more defensible of the two, improving both IRR and MDD simultaneously without depending on an unobservable option-pricing assumption."
  )]),
  p([run(
    "This paper explores a third, structurally simpler axis, orthogonal to both: rather than modifying the sizing or hedging rule of a single grid, we run several DGT instances in parallel at different geometric spacings k_i, splitting total capital across them by fixed weight w_i. We call the resulting strategy Dynamic Multigrid Trading (DMT). The motivating intuition is that a tightly-spaced grid captures range-bound, high-frequency oscillation efficiently but participates poorly in sustained directional moves, while a widely-spaced grid does the opposite; combining several spacings should let capital allocate itself, in effect, across market regimes without having to forecast which regime is coming. A further, specifically risk-oriented intuition \u2014 and the original motivation for this study \u2014 is that grids of different width will not reach their own worst drawdown at exactly the same moment, so an ensemble's maximum drawdown should be shallower than any single constituent's, even if the ensemble's return is close to a capital-weighted average of the constituents' returns."
  )]),
  p([run(
    "We test this intuition directly against 3.5 years of real exchange data and find that it is only partially correct. Section V shows that the apparent \u201cfree\u201d drawdown improvement from wide grids is a statistical artifact of too few reset events, that a principled reset-count admissibility filter removes this artifact, and that once removed, the surviving ensembles deliver a real, defensible improvement in return and risk-adjusted return \u2014 but not in maximum drawdown itself. Section V-E traces this directly to near-total synchronization of drawdown timing across differently-spaced grids trading the same underlying asset."
  )]),
  heading1("II", "Related Work"),
  p([run(
    "Grid and channel-following trading rules have a long history in retail and algorithmic FX and crypto trading [3], [4]; most published treatments are empirical or heuristic rather than derived from an expectation argument, which is the specific gap [1] fills. Portfolio-insurance and constant-proportion strategies [5]\u2013[7] share DGT's asymmetric response to drawdowns, though they operate on a single continuously-rebalanced position rather than a discretized ladder of limit orders; the growth-optimal, anti-martingale sizing principle underlying the position throttle of [2] traces to Kelly's criterion [8], a distinct idea from portfolio insurance mentioned here only for that lineage. The inventory-skewing quotes of market-making frameworks such as Avellaneda\u2013Stoikov [9] address a related but distinct problem \u2014 managing directional exposure risk from resting limit orders \u2014 and, like this paper's Section V-E, ultimately confront the limits of diversification when all instruments share a common underlying risk factor."
  )]),
  p([run(
    "Backtest overfitting is a central methodological concern for any parameter-searched trading rule. Bailey and L\u00f3pez de Prado [10] and Bailey et al. [11] formalize the risk that optimizing a performance statistic over a wide parameter grid on a single historical path selects configurations whose apparent edge is a sampling artifact rather than a real effect; [2, Sec. V-B] documents a concrete instance of this within DGT's own grid-size/half-width search space (unconstrained optimization degenerates to grids so wide they almost never trigger). Section V of this paper documents the same failure mode re-emerging at the ensemble level, and Section III-C proposes a reset-count admissibility rule as a lightweight, non-parametric safeguard against it, in the same spirit as the resets\u226540 constraint used in [2]."
  )]),
  p([run(
    "Standard performance statistics in this literature include the Sharpe ratio [12], maximum drawdown [13], [14], and the Calmar ratio (IRR divided by |MDD|); this paper reports the latter two plus IRR (Section III-D), consistent with [1] and [2]. Bitcoin's return-generating process is known to exhibit heavier tails and more volatility clustering than developed-market equities [15]\u2013[17]; we do not model this directly, but it underlies why a single historical path (even one spanning 3.5 years) contains a limited number of effectively independent large-drawdown events \u2014 the central obstacle identified in Section V-E."
  )]),
];

module.exports = { section1_intro };
