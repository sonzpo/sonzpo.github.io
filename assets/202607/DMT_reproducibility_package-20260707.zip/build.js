const H = require("./helpers");
const { Document, Packer, Paragraph, TextRun, AlignmentType, SectionType,
  Header, Footer, PageNumber } = H;

const { titleBlock, abstractBlock } = require("./part1_title");
const { section1_intro } = require("./part2_intro_related");
const { section3_method, section4_data } = require("./part3_method_data");
const { section5_results } = require("./part4_results");
const { section6_discussion, references, appendix } = require("./part5_discussion_refs");

const allBodyChildren = [
  ...section1_intro,
  ...section3_method,
  ...section4_data,
  ...section5_results,
  ...section6_discussion,
  ...references,
  ...appendix,
];

const doc = new Document({
  sections: [
    // Section 1: single-column title + abstract (typical IEEE layout)
    {
      properties: {
        page: {
          size: { width: 12240, height: 15840 },
          margin: { top: 1080, right: 900, bottom: 1440, left: 900, header: 708, footer: 708 },
        },
      },
      children: titleBlock.concat(abstractBlock),
    },
    // Section 2: two-column body
    // 第二節：雙欄正文 —— 使用 CONTINUOUS 分節，緊接摘要同頁接續
    // （比照 DGTAP 論文格式：word/document.xml 中第二個 sectPr 為
    // <w:type w:val="continuous"/>，並非另起新頁）
    {
      properties: {
        type: SectionType.CONTINUOUS,
        page: {
          size: { width: 12240, height: 15840 },
          margin: { top: 1080, right: 900, bottom: 1440, left: 900, header: 708, footer: 708 },
        },
        column: { count: 2, space: 288 },
      },
      children: allBodyChildren,
    },
  ],
});

Packer.toBuffer(doc).then(buf => {
  require("fs").writeFileSync("DMT_paper.docx", buf);
  console.log("written DMT_paper.docx", buf.length, "bytes");
});
