const {
  Document, Packer, Paragraph, TextRun, HeadingLevel, AlignmentType,
  Table, TableRow, TableCell, WidthType, ShadingType, BorderStyle,
  ImageRun, PageOrientation, SectionType, TabStopType, TabStopPosition,
  Header, Footer, PageNumber, LevelFormat, convertInchesToTwip,
} = require("docx");
const fs = require("fs");

const FONT = "Times New Roman";
const SZ_TITLE = 32;   // 16pt
const SZ_AUTHOR = 22;  // 11pt
const SZ_ABSTRACT = 18; // 9pt
const SZ_BODY = 20;    // 10pt
const SZ_HEAD1 = 20;   // 10pt small caps bold centered
const SZ_HEAD2 = 20;   // 10pt italic
const SZ_CAPTION = 16; // 8pt
const SZ_TABLE = 16;   // 8pt

function img(path, width, height) {
  const data = fs.readFileSync(path);
  return new ImageRun({ data, transformation: { width, height }, type: "png" });
}

let DEFAULT_ALIGN = AlignmentType.JUSTIFIED;
function setDefaultAlign(a) { DEFAULT_ALIGN = a; }

function p(children, opts = {}) {
  return new Paragraph({
    children: Array.isArray(children) ? children : [children],
    alignment: opts.align || DEFAULT_ALIGN,
    spacing: { after: opts.after !== undefined ? opts.after : 120, line: opts.line || 264 },
    indent: opts.indent,
    keepLines: opts.keepLines,
  });
}

const CJK_FONT = "SimSun";

function run(text, opts = {}) {
  return new TextRun({
    text,
    font: { ascii: FONT, hAnsi: FONT, eastAsia: opts.cjkFont || CJK_FONT },
    size: opts.size || SZ_BODY, bold: opts.bold, italics: opts.italics,
    superScript: opts.sup, subScript: opts.sub, smallCaps: opts.smallCaps,
  });
}

function heading1(num, title) {
  return new Paragraph({
    children: [run(`${num}.  ${title.toUpperCase()}`, { size: SZ_HEAD1, bold: true })],
    alignment: AlignmentType.CENTER,
    spacing: { before: 220, after: 140 },
  });
}

function heading2(letter, title) {
  return new Paragraph({
    children: [run(`${letter}. ${title}`, { size: SZ_HEAD2, italics: true })],
    spacing: { before: 160, after: 80 },
  });
}

function caption(text) {
  return new Paragraph({
    children: [run(text, { size: SZ_CAPTION })],
    alignment: AlignmentType.CENTER,
    spacing: { before: 60, after: 160 },
  });
}

function figureImage(path, w, h, capText) {
  return [
    new Paragraph({
      children: [img(path, w, h)],
      alignment: AlignmentType.CENTER,
      spacing: { before: 120, after: 40 },
    }),
    caption(capText),
  ];
}

const COLUMN_WIDTH_TWIPS = 5076; // (12240-900-900-288)/2，雙欄版面單欄實際可用寬度

function eqBlock(path, w, h, num) {
  return new Paragraph({
    tabStops: [{ type: TabStopType.RIGHT, position: COLUMN_WIDTH_TWIPS }],
    children: [
      img(path, w, h),
      new TextRun({ text: `\t(${num})`, font: FONT, size: SZ_BODY }),
    ],
    spacing: { before: 100, after: 100 },
  });
}

function cell(text, opts = {}) {
  return new TableCell({
    width: { size: opts.width || 1000, type: WidthType.DXA },
    shading: opts.shade ? { type: ShadingType.CLEAR, fill: "D9D9D9" } : undefined,
    margins: { top: 40, bottom: 40, left: 60, right: 60 },
    children: [new Paragraph({
      alignment: opts.align || AlignmentType.CENTER,
      children: [run(text, { size: SZ_TABLE, bold: opts.bold })],
    })],
  });
}

function tableCaption(romanNum, title, labelWord = "TABLE") {
  return [
    new Paragraph({
      children: [run(`${labelWord} ${romanNum}`, { size: SZ_TABLE, smallCaps: true })],
      alignment: AlignmentType.CENTER,
      spacing: { before: 160, after: 20 },
    }),
    new Paragraph({
      children: [run(title, { size: SZ_TABLE })],
      alignment: AlignmentType.CENTER,
      spacing: { after: 80 },
    }),
  ];
}

function makeTable(headers, rows, colWidths) {
  const totalW = colWidths.reduce((a, b) => a + b, 0);
  const headerRow = new TableRow({
    children: headers.map((h, i) => cell(h, { width: colWidths[i], bold: true, shade: true })),
    tableHeader: true,
    cantSplit: true,
  });
  const bodyRows = rows.map(r => new TableRow({
    children: r.map((c, i) => cell(String(c), { width: colWidths[i] })),
    cantSplit: true,
  }));
  return new Table({
    width: { size: totalW, type: WidthType.DXA },
    columnWidths: colWidths,
    rows: [headerRow, ...bodyRows],
  });
}

module.exports = { Document, Packer, Paragraph, TextRun, HeadingLevel, AlignmentType,
  Table, TableRow, TableCell, WidthType, ShadingType, BorderStyle, ImageRun,
  PageOrientation, SectionType, TabStopType, TabStopPosition, Header, Footer, PageNumber,
  LevelFormat, convertInchesToTwip, FONT, SZ_TITLE, SZ_AUTHOR, SZ_ABSTRACT, SZ_BODY,
  SZ_HEAD1, SZ_HEAD2, SZ_CAPTION, SZ_TABLE, img, p, run, heading1, heading2, caption,
  figureImage, eqBlock, cell, makeTable, tableCaption, setDefaultAlign };
