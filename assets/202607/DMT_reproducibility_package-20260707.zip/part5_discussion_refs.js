const H = require("./helpers");
const { p, run, heading1, heading2 } = H;

const section6_discussion = [
  heading1("VI", "Discussion and Limitations"),

  heading2("A", "The Leg-Selection Pool Is Itself a Soft In-Sample Search"),
  p([run(
    "Even after applying the dynamic reset-count threshold, the admissible legs used to build DMT-3/5/7 in Section V-D were ranked by Calmar ratio computed on the same 2021\u20132024 historical path used to report final performance. The reset-count filter removes the most egregious form of overfitting (near-zero-event configurations) but does not eliminate look-ahead entirely: a practitioner deploying DMT live would need to fix leg spacings before observing this specific price path, e.g., via walk-forward validation across non-overlapping historical windows or, ideally, an independent asset/period. We did not have access to a second comparably long, comparably clean real-data window and flag this as the most important open validation step before any live deployment."
  )]),

  heading2("B", "Complementarity With DGTAP"),
  p([run(
    "DMT and the throttle/put extensions of [2] target different, non-exclusive weaknesses of the DGT mechanism. DMT's best statistically-defensible result (Section V-D) improves IRR and Calmar with MDD essentially flat; the anti-martingale throttle of [2, Table II] improves MDD by 7.12 percentage points with IRR essentially flat (+0.89 pp). This pattern \u2014 DMT moving the numerator of the Calmar ratio, throttle moving the denominator \u2014 suggests the two mechanisms may stack: an ensemble of throttled DGT legs at different spacings. We did not test this combination; it is the natural next step and is left to future work."
  )]),

  heading2("C", "Sensitivity of the Dynamic Threshold Constants"),
  p([run(
    "R_lo=20, R_hi=5, and the log-linear interpolation form of Eq. (3) were chosen as reasonable, round-number defaults rather than derived from a formal statistical power calculation. We do not report a sensitivity sweep over these constants; a more rigorous version of this admissibility rule would tie R_min(k) to an explicit confidence interval on the Calmar ratio as a function of the number of independent reset events, analogous to a minimum-sample-size calculation, rather than to fixed endpoints chosen by inspection."
  )]),

  heading2("D", "Single-Asset, Single-Window Evaluation"),
  p([run(
    "As in [2], all results use BTC/USD only, over one historical period (2021\u20132024). This is precisely the limitation that Section V-E identifies as the mechanical reason DMT does not improve MDD: every leg is exposed to the same underlying risk factor, so the ensemble cannot diversify away the single largest realized drawdown event. A genuinely decorrelated multigrid ensemble \u2014 for example, running legs on BTC, ETH, and a handful of other liquid pairs simultaneously, or combining spacing diversification with the throttle of [2] \u2014 might realize the timing-diversification benefit that spacing alone does not; we did not have comparably clean multi-asset minute data available to test this and leave it to future work."
  )]),

  heading1("VII", "Conclusion"),
  p([run(
    "We proposed Dynamic Multigrid Trading (DMT), an ensemble of independently-reset DGT instances at different grid spacings, motivated by the intuition that differently-spaced grids would respond to the same price history with different timing and thereby reduce ensemble-level maximum drawdown relative to any single grid. Capital allocation across legs was verified to be exactly proportional (Section III-A), ruling out sizing error as an explanation for any result. Testing this intuition against 3.5 years of real Bitstamp BTC/USD data, we found that naive fixed-range ensembles are not robustly better than a single well-chosen grid, and that the most dramatic apparent improvements \u2014 12+ percentage points of MDD reduction from wide-spacing ensembles \u2014 are a reset-count-driven overfitting artifact, the same pathology [2] documents for single-grid parameter search. Introducing a spacing-dependent dynamic reset-count admissibility threshold and restricting the leg pool accordingly, we obtained a defensible result: a 3-leg ensemble improves IRR by 3.46 percentage points and the Calmar ratio by 16.9% relative to the published DGT baseline. Maximum drawdown, however, does not improve \u2014 a drawdown-synchronization analysis (Section V-E) shows that at the ensemble's own worst moment, every constituent leg is simultaneously at its own individual all-time-worst drawdown, leaving no timing-diversification benefit to be realized from spacing alone on a single underlying asset. We conclude that same-asset multigrid spacing is a modest, real source of return improvement but is not, by itself, a reliable tool for tail-risk reduction, and recommend that practitioners seeking lower drawdown combine DMT with the throttle mechanism of [2] rather than relying on spacing diversification alone \u2014 a combination we did not test here and flag as the primary direction for future work."
  )]),
];

const references = [
  new (require("docx").Paragraph)({
    children: [new (require("docx").TextRun)({ text: "REFERENCES", font: H.FONT, size: H.SZ_HEAD1, bold: true })],
    alignment: require("docx").AlignmentType.CENTER, spacing: { before: 220, after: 140 },
  }),
];

function ref(num, text) {
  return p([run(`[${num}]  ${text}`, { size: 18 })], { after: 60, align: require("docx").AlignmentType.LEFT, line: 250 });
}

references.push(
  ref(1, "K.-Y. Chen, K.-H. Chen, and J.-S. R. Jang, \u201cDynamic Grid Trading Strategy: From Zero Expectation to Market Outperformance,\u201d arXiv preprint arXiv:2506.11921, 2025."),
  ref(2, "DGTAP Project, \u201cDynamic Grid Trading with Anti-Martingale Sizing and Protective Options: An Extension Toward Bounded Tail Risk,\u201d unpublished companion technical report, 2026."),
  ref(3, "F. Rundo, F. Trenta, A. L. di Stallo, and S. Battiato, \u201cGrid Trading System Robot (GTSbot): A Novel Mathematical Algorithm for Trading FX Market,\u201d Applied Sciences, vol. 9, no. 9, p. 1796, 2019."),
  ref(4, "F. Rundo, F. Trenta, A. L. di Stallo, and S. Battiato, \u201cAdvanced Markov-Based Machine Learning Framework for Making Adaptive Trading System,\u201d Computation, vol. 7, no. 1, p. 4, 2019."),
  ref(5, "H. E. Leland and M. Rubinstein, \u201cThe Evolution of Portfolio Insurance,\u201d in Portfolio Insurance: A Guide to Dynamic Hedging, D. L. Luskin, Ed. New York: Wiley, 1976."),
  ref(6, "F. Black and R. Jones, \u201cSimplifying Portfolio Insurance,\u201d Journal of Portfolio Management, vol. 14, no. 1, pp. 48\u201351, 1987."),
  ref(7, "F. Black and A. R. Perold, \u201cTheory of Constant Proportion Portfolio Insurance,\u201d Journal of Economic Dynamics and Control, vol. 16, no. 3\u20134, pp. 403\u2013426, 1992."),
  ref(8, "J. L. Kelly Jr., \u201cA New Interpretation of Information Rate,\u201d Bell System Technical Journal, vol. 35, no. 4, pp. 917\u2013926, 1956."),
  ref(9, "M. Avellaneda and S. Stoikov, \u201cHigh-Frequency Trading in a Limit Order Book,\u201d Quantitative Finance, vol. 8, no. 3, pp. 217\u2013224, 2008."),
  ref(10, "D. H. Bailey and M. L\u00f3pez de Prado, \u201cThe Deflated Sharpe Ratio: Correcting for Selection Bias, Backtest Overfitting, and Non-Normality,\u201d Journal of Portfolio Management, vol. 40, no. 5, pp. 94\u2013107, 2014."),
  ref(11, "D. H. Bailey, J. Borwein, M. L\u00f3pez de Prado, and Q. J. Zhu, \u201cThe Probability of Backtest Overfitting,\u201d Journal of Computational Finance, vol. 20, no. 4, pp. 39\u201369, 2017."),
  ref(12, "W. F. Sharpe, \u201cThe Sharpe Ratio,\u201d Journal of Portfolio Management, vol. 21, no. 1, pp. 49\u201358, 1994."),
  ref(13, "M. Magdon-Ismail and A. F. Atiya, \u201cMaximum Drawdown,\u201d Risk Magazine, vol. 17, no. 10, pp. 99\u2013102, 2004."),
  ref(14, "M. Magdon-Ismail, A. F. Atiya, A. Pratap, and Y. S. Abu-Mostafa, \u201cOn the Maximum Drawdown of a Brownian Motion,\u201d Journal of Applied Probability, vol. 41, no. 1, pp. 147\u2013161, 2004."),
  ref(15, "R. Cont, \u201cEmpirical Properties of Asset Returns: Stylized Facts and Statistical Issues,\u201d Quantitative Finance, vol. 1, no. 2, pp. 223\u2013236, 2001."),
  ref(16, "P. Katsiampa, \u201cVolatility Estimation for Bitcoin: A Comparison of GARCH Models,\u201d Economics Letters, vol. 158, pp. 3\u20136, 2017."),
  ref(17, "A. H. Dyhrberg, \u201cHedging Capabilities of Bitcoin. Is It the Virtual Gold?,\u201d Finance Research Letters, vol. 16, pp. 139\u2013144, 2016."),
);

const appendix = [
  new (require("docx").Paragraph)({
    children: [new (require("docx").TextRun)({ text: "APPENDIX A\nCODE AND REPRODUCIBILITY", font: H.FONT, size: H.SZ_HEAD1, bold: true })],
    alignment: require("docx").AlignmentType.CENTER, spacing: { before: 220, after: 140 },
  }),
  p([run(
    "The DMT ensemble wrapper (DMTMultigrid) is implemented in Python and calls the DGTStrategy engine of [2] once per leg with principal = w_i \u00b7 M, throttle and put overlay disabled, then sums the resulting equity_curve Series across legs. Key scripts developed for this paper: (i) a full single-grid parameter sweep across grid_size \u00d7 half_n (Section V, Figs. 1\u20132); (ii) the dynamic reset-count threshold filter (Eq. 3\u20134) applied to the sweep output; (iii) the DMT-3/5/7 ensemble construction and comparison against the DGT baseline and Buy & Hold (Table, Section V-D); and (iv) the drawdown-synchronization diagnostic (Eq. 8, Section V-E). The headline DMT-3 configuration is {(k=2.5%, m=6), (k=3.5%, m=6), (k=5.0%, m=6)}, equal weight 1/3 per leg, principal 100, fee 8 bps, throttle and put overlay disabled. All backtests reuse the Bitstamp BTC/USD 1-minute dataset (2021-01-01\u20132024-07-31) and the DGTStrategy engine distributed with the reproducibility package of [2]; no new market data was collected for this paper.",
    { size: 18 })], { line: 250 }),
];

module.exports = { section6_discussion, references, appendix };
