import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
plt.rcParams.update({'font.size': 15, 'font.family': 'STIXGeneral', 'mathtext.fontset': 'stix'})

def render(tex, name, fontsize=15, w=6, h=0.8):
    fig = plt.figure(figsize=(w, h), dpi=300)
    fig.text(0.02, 0.5, tex, fontsize=fontsize, va='center', ha='left')
    fig.savefig(f'eqs/{name}.png', transparent=True, bbox_inches='tight', pad_inches=0.05)
    plt.close(fig)

render(r'$V_{DMT}(t) = \sum_{i=1}^{N} w_i\, V_i(t), \qquad \sum_{i=1}^{N} w_i = 1,\ w_i \geq 0$', 'eq1_ensemble', w=7.2)
render(r'$M_i = w_i \cdot M_{total}$', 'eq2_leg_capital')
render(r'$R_{\min}(k) = R_{lo} + (R_{hi}-R_{lo})\cdot \mathrm{clip}\!\left(\frac{\ln k - \ln k_{\min}}{\ln k_{\max}-\ln k_{\min}},\,0,\,1\right)$', 'eq3_dynthresh', w=7.6)
render(r'$\mathrm{leg}_i \ \mathrm{admissible} \Leftrightarrow \mathrm{resets}_i \geq R_{\min}(k_i)$', 'eq4_admissible', w=6.8)
render(r'$IRR = \left(\frac{V_T}{V_0}\right)^{1/T_{yr}} - 1$', 'eq5_irr')
render(r'$MDD = \min_{t}\ \frac{V_t - \max_{s\leq t} V_s}{\max_{s\leq t} V_s}$', 'eq6_mdd', w=6.5)
render(r'$Calmar = \frac{IRR}{|MDD|}$', 'eq7_calmar')
render(r'$SI = \frac{1}{N}\sum_{i=1}^{N} \mathbb{1}\!\left[\,DD_i(t^\ast) \geq (1-\epsilon)\cdot MDD_i\,\right], \quad t^\ast = \arg\min_t\, DD_{DMT}(t)$', 'eq8_syncindex', w=7.8)
print("done")
