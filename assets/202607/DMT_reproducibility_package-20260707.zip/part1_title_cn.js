const H = require("./helpers");
const {
  Document, Packer, Paragraph, TextRun, AlignmentType, SectionType,
  Header, Footer, PageNumber, convertInchesToTwip,
  p, run, heading1, heading2, caption, figureImage, eqBlock, makeTable, img,
} = H;

const EQ = "eqs/", FIG = "figs/";

const titleBlock = [
  new Paragraph({
    children: [run("动态多重网格交易：一种基于重置次数约束的动态网格交易集成式扩展",
      { size: H.SZ_TITLE, bold: true })],
    alignment: AlignmentType.CENTER, spacing: { after: 160 },
  }),
  new Paragraph({
    children: [run("[作者姓名待补充]", { size: H.SZ_AUTHOR })],
    alignment: AlignmentType.CENTER, spacing: { after: 20 },
  }),
  new Paragraph({
    children: [run("[所属单位待补充]", { size: H.SZ_AUTHOR, italics: true })],
    alignment: AlignmentType.CENTER, spacing: { after: 20 },
  }),
  new Paragraph({
    children: [run("2026年7月", { size: H.SZ_AUTHOR })],
    alignment: AlignmentType.CENTER, spacing: { after: 200 },
  }),
  p([run(
    "来源说明：本文延伸自Chen、Chen与Jang [1]提出的动态重置网格交易框架(\u201cDGT\u201d)，并与另一篇姊妹扩展报告(\u201cDGTAP\u201d)[2]中提出的反马丁格尔仓位节流/保护性认沽期权框架并列。多重网格集成架构、动态重置次数准入准则，以及第五至六节中的所有回测结果均为本文原创，且皆使用与[2]相同的真实市场数据集产生，以确保可直接比较。",
    { size: H.SZ_ABSTRACT, italics: true })], { after: 160 }),
];

const abstractBlock = [
  p([
    run("摘要\u2014", { size: H.SZ_ABSTRACT, bold: true, italics: true }),
    run(
      "动态网格交易(DGT)透过「触及边界即以当前价格重新铺设网格，而非结算离场」的机制，打破了天真网格交易期望值为零的结论，但单一网格间距必须在「捕捉区间震荡」与「捕捉大幅单边行情」之间做出取舍。本文提出动态多重网格交易(Dynamic Multigrid Trading, DMT):以不同的等比间距 k_i 并行运行多组各自独立重置的DGT实例，并以固定权重 w_i 将总资金分配至各组网格。我们在3.5年的真实Bitstamp BTC/USD 1分钟数据(与[2]采用相同数据集)上验证发现：(i) 涵盖任意间距范围的天真等权重集成组合，并不稳健地优于单一挑选得当的网格；(ii) 表面上能将最大回撤(MDD)降低超过12个百分点的宽间距集成组合，其改善其实只是因为这些子网格触发的重置事件太少而缺乏统计意义\u2014\u2014这正是[2, Sec. V-B]所记录的网格参数搜索过度配适问题，如今在集成层级重新浮现；以及(iii) 在引入与间距相关的动态重置次数准入门槛、并据此限制候选网格池之后，一个三组网格的集成组合({2.5%, 3.5%, 5.0%}, m=6, 等权重)相对已发表的DGT基准，年化报酬率(IRR)提升3.46个百分点、Calmar比率提升16.9%,而MDD基本维持不变(\u22120.10个百分点)。我们进一步追溯发现，这最后一项结果源于不同间距网格在同一标的资产上的回撤时点几乎完全同步：在集成组合自身表现最差的时刻(2022年6月的Terra/3AC崩盘事件)，三组网格同时都处于各自历史最大回撤的谷底。我们得出结论：同一资产上的间距分散是一种适度但具统计支撑的报酬与风险调整后报酬改善来源，但就其本身而言，并非降低尾部风险的可靠工具\u2014\u2014在这方面，[2]中的节流/期权机制仍是更有效的手段。",
      { size: H.SZ_ABSTRACT }),
  ], { after: 100 }),
  p([
    run("索引词\u2014", { size: H.SZ_ABSTRACT, bold: true, italics: true }),
    run("算法交易、网格交易、集成方法、加密货币、回测过度配适、回撤、比特币、动态网格交易。", { size: H.SZ_ABSTRACT }),
  ], { after: 160 }),
];

module.exports = { titleBlock, abstractBlock, EQ, FIG };
