const H = require("./helpers");
const { AlignmentType, Paragraph, p, run, heading1, heading2, makeTable, tableCaption, figureImage } = H;
const FIG = "figs/";

const section5_results = [
  heading1("V", "Results"),

  heading2("A", "Pitfall 1: Naive Fixed-Range Ensembles Are Not Robustly Better Than the Single-Grid Baseline"),
  p([run(
    "As a first, deliberately unoptimized test, we built 3-, 5-, and 7-leg ensembles with spacings drawn as a geometric sequence over 1.8%\u20135.0% (all m=6, equal weight 1/N per leg) \u2014 a plausible choice a practitioner might make without any historical-parameter search. None outperforms the published DGT baseline (k=2.5%, m=6: IRR 20.20%, MDD \u221246.29%, Calmar 0.436, 73 resets)."
  )]),
  ...tableCaption("I", "Naive Fixed-Range DMT Ensembles vs. the DGT Baseline"),
  makeTable(
    ["Ensemble", "IRR", "MDD", "Calmar", "\u0394IRR (pp)", "\u0394MDD (pp)"],
    [
      ["DMT-3grid (1.8/3.0/5.0%)", "18.98%", "\u221248.35%", "0.393", "\u22121.22", "\u22122.06"],
      ["DMT-5grid", "17.69%", "\u221248.65%", "0.364", "\u22122.51", "\u22122.36"],
      ["DMT-7grid", "20.30%", "\u221249.43%", "0.411", "+0.10", "\u22123.14"],
    ],
    [1700, 750, 750, 700, 650, 650]
  ),
  new Paragraph({ children: [], spacing: { after: 120 } }),
  p([run(
    "\u0394MDD is reported such that a positive value means MDD improved (shallower); all three configurations are negative here, i.e., every naive ensemble tested has a deeper drawdown than the single baseline it is meant to improve on, in addition to lower IRR in two of three cases."
  )]),

  heading2("B", "Pitfall 2: Wide-Spacing Ensembles Appear to Cut MDD but Fail the Reset-Count Test"),
  p([run(
    "Repeating the exercise with wider spacings (10%\u201330%) reproduces the same qualitative failure as Section V-A (not tabulated here for brevity). A second, more adversarial variant instead deliberately selects the individually highest-Calmar single grid available anywhere in the full grid_size \u00d7 half_n parameter sweep (0.8%\u201330%) at each ensemble size, and produces a striking apparent improvement:"
  )]),
  ...tableCaption("II", "Curated Wide-Spacing Ensembles: Apparent MDD Gains That Fail the Reset-Count Test"),
  makeTable(
    ["Ensemble (curated, high-Calmar legs)", "IRR", "MDD", "Calmar", "\u0394MDD (pp)", "Total resets"],
    [
      ["DMT-3grid (15%/25%/12%)", "22.55%", "\u221233.82%", "0.667", "+12.47", "2"],
      ["DMT-5grid", "22.21%", "\u221234.03%", "0.653", "+12.26", "17"],
      ["DMT-7grid", "21.14%", "\u221233.95%", "0.623", "+12.34", "17"],
    ],
    [1900, 750, 750, 700, 750, 650]
  ),
  new Paragraph({ children: [], spacing: { after: 120 } }),
  p([run(
    "A 12+ percentage point MDD improvement looks decisive, but most contributing legs individually reset only 0\u20131 times over the full 3.5-year backtest (e.g., k=15%, m=8 resets zero times; k=25%, m=4 resets once); the 5- and 7-leg variants additionally include k=5%, m=6 (15 resets), the most active leg in the pool and still short of the resets\u226520 threshold used for single grids in [2]. This is the ensemble-level analogue of the exact overfitting pattern documented for single grids in [2, Sec. V-B]: the grid is simply wide enough that the realized 2021\u20132024 BTC price path never (or almost never) escaped it, so the backtest is closer to measuring \u201cdid buy-and-hold-shaped exposure with a wide band happen to work this one time\u201d than \u201cdoes the dynamic reset mechanism add value.\u201d Fig. 1 shows this pattern across the full single-grid sweep: Calmar ratio rises roughly monotonically with spacing in the reset-starved region, exactly mirroring the degenerate optimum reported in [2, Fig. 1] for the single-grid case."
  )]),
  ...figureImage(FIG + "fig1_calmar_vs_spacing.png", 260, 160,
    "Fig. 1. Calmar ratio vs. grid spacing across the full single-grid sweep. Configurations failing the dynamic reset-count threshold of Section III-C (gray) are concentrated exclusively at the wide end of the spacing axis (k \u2265 5%); every narrow-spacing configuration tested (k \u2264 2%) triggers far more resets than its threshold requires and passes easily."),

  heading2("C", "A Dynamically Filtered Ensemble"),
  p([run(
    "Applying the threshold of Eq. (3)\u2013(4) with R_lo=20, R_hi=5 across the observed spacing range (0.8%\u201330%) yields the admissibility curve in Fig. 2. Twenty-six of the 47 single-grid configurations in the combined sweep pass; critically, every wide (>10%) configuration used in Section V-B's curated ensemble fails."
  )]),
  ...figureImage(FIG + "fig2_dynamic_threshold.png", 260, 160,
    "Fig. 2. Dynamic reset-count threshold R_min(k) (black curve) against observed reset counts per configuration. Blue points pass the threshold; gray points fail."),
  p([run(
    "Ranking admissible configurations by Calmar ratio gives a pool headed by k=3.5% (m=6, Calmar 0.545, 32 resets), k=5.0% (m=6, Calmar 0.528, 15 resets \u2014 admissible because the dynamic threshold at 5% spacing is only 12.4), and the DGT baseline itself, k=2.5% (m=6, Calmar 0.436, 73 resets)."
  )]),

  heading2("D", "DMT-3/5/7 Under the Dynamic Threshold"),
  p([run(
    "Building 3-, 5-, and 7-leg ensembles from the top of this admissible, Calmar-ranked pool (equal weight per leg) gives the headline result of this paper:"
  )]),
  ...tableCaption("III", "DMT-3/5/7 Under the Dynamic Reset-Count Threshold"),
  makeTable(
    ["Strategy", "IRR", "MDD", "Calmar", "\u0394IRR (pp)", "\u0394MDD (pp)", "Resets"],
    [
      ["Buy & Hold", "25.93%", "\u221277.54%", "0.334", "+5.73", "\u221231.25", "\u2014"],
      ["DGT baseline (k=2.5%, m=6)", "20.20%", "\u221246.29%", "0.436", "\u2014", "\u2014", "73"],
      ["DMT-3 (2.5/3.5/5.0%, dyn.)", "23.67%", "\u221246.39%", "0.510", "+3.46", "\u22120.10", "120"],
      ["DMT-5 (dyn.)", "22.13%", "\u221247.34%", "0.467", "+1.93", "\u22121.05", "211"],
      ["DMT-7 (dyn.)", "20.47%", "\u221247.37%", "0.432", "+0.27", "\u22121.08", "240"],
    ],
    [1100, 650, 700, 600, 600, 600, 600]
  ),
  new Paragraph({ children: [], spacing: { after: 120 } }),
  p([run(
    "DMT-3 (equal-weight {2.5%, 3.5%, 5.0%}, m=6) delivers the best result in the paper on statistically defensible grounds: IRR improves by 3.46 percentage points and Calmar by 16.9% relative to the DGT baseline, while MDD is essentially unchanged (\u22120.10 pp \u2014 within noise). Adding legs beyond three is not monotonically helpful: DMT-5 and DMT-7 dilute capital into progressively lower-Calmar admissible legs (Section V-C), and both the return and risk-adjusted-return advantage shrink monotonically as a result. By DMT-7, the Calmar ratio (0.432) has already fallen slightly below the DGT baseline (0.436), even though IRR remains marginally higher (+0.27 pp) \u2014 the added legs' own trading and reset costs (Resets column, Table III) consume the three-leg ensemble's advantage before it carries through to seven legs. Fig. 4 plots the mark-to-market equity curve of DMT-3 against Buy & Hold and the DGT baseline."
  )]),
  ...figureImage(FIG + "fig4_equity.png", 260, 163,
    "Fig. 4. Mark-to-market equity curves for Buy & Hold, the DGT baseline, and DMT-3 (dynamic threshold), daily-resampled, BTC/USD, Jan 2021\u2013Jul 2024, log scale."),

  heading2("E", "Why MDD Does Not Improve: Drawdown-Timing Synchronization"),
  p([run(
    "To understand why even the best statistically-admissible ensemble fails to improve MDD, we evaluated the synchronization index of Eq. (8) for DMT-3 at t*, the timestamp of the ensemble's own worst drawdown. t* falls on June 19, 2022, during the Terra/Luna and Three Arrows Capital deleveraging cascade \u2014 the single largest drawdown event in the 2021\u20132024 window for every strategy tested in this paper (DGT baseline, Buy & Hold, and all DMT variants), and the same mid-2022 period in which [2, Fig. 4] independently reports its own DGT-family equity curves visibly decoupling."
  )]),
  ...tableCaption("IV", "Drawdown Synchronization Across DMT-3 Legs at the Ensemble's Own Worst Moment"),
  makeTable(
    ["Leg", "Drawdown at t*", "Leg's own all-time MDD", "Synchronized?"],
    [
      ["k=3.5%, m=6", "\u221251.66%", "\u221251.66%", "Yes (exact)"],
      ["k=5.0%, m=6", "\u221242.20%", "\u221242.20%", "Yes (exact)"],
      ["k=2.5%, m=6", "\u221246.29%", "\u221246.29%", "Yes (exact)"],
    ],
    [1200, 1300, 1600, 1400]
  ),
  new Paragraph({ children: [], spacing: { after: 120 } }),
  p([run(
    "All three legs are, to floating-point precision, exactly at their own individual all-time-worst drawdown at the exact moment the ensemble is at its worst: SI = 1.00. There is zero realized timing diversification. This is the direct, quantitative explanation for Section V-D's finding: because every leg trades the same underlying price path, a large-enough systemic move (here, BTC fell roughly 63% peak-to-trough between April 4 and June 19, 2022, a span of about ten weeks) pushes every constituent grid \u2014 regardless of spacing \u2014 to its own worst point at essentially the same time. Fig. 3 visualizes this."
  )]),
  ...figureImage(FIG + "fig3_sync.png", 260, 160,
    "Fig. 3. Drawdown synchronization across the three DMT-3 legs. For every leg, drawdown at the ensemble's own worst moment (t* = 2022-06-19, red) exactly equals that leg's own all-time-worst drawdown (blue)."),
];

module.exports = { section5_results };
