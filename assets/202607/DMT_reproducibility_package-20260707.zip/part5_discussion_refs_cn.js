const H = require("./helpers");
const { p, run, heading1, heading2 } = H;

const section6_discussion = [
  heading1("六", "讨论与局限"),

  heading2("A", "候选网格池的挑选本身仍是一种弱式样本内搜索"),
  p([run(
    "即便套用了动态重置次数门槛，第五节D部分用来建立DMT-3/5/7的可采纳网格，仍是依据同一段2021\u20132024历史价格路径所计算出的Calmar比率来排序。重置次数筛选剔除了最严重的过度配适形式(重置事件数近乎为零的配置)，但并未完全消除「事后选择」的问题：实际部署DMT策略的从业者，理应在观察到这段特定价格路径之前就固定好各组网格的间距\u2014\u2014例如透过跨多个不重叠历史区间的前向验证(walk-forward validation)，或理想情况下使用一个独立的资产/时间区间。我们目前并未取得第二段品质相当、时间跨度相当的真实数据窗口，因此将这一点标注为在实际部署前最重要的、尚待完成的验证步骤。"
  )]),

  heading2("B", "与DGTAP的互补性"),
  p([run(
    "DMT与 [2] 中的节流/认沽期权扩展，针对的是DGT机制中不同、且并不互斥的弱点。DMT在第五节D部分的最佳、具统计支撑的成果，改善了IRR与Calmar,MDD则基本持平；而 [2, Table II] 中的反马丁格尔节流机制则改善了MDD达7.12个百分点，IRR基本持平(+0.89个百分点)。这一模式\u2014\u2014DMT改动的是Calmar比率的分子，节流机制改动的是分母\u2014\u2014暗示这两种机制或许可以叠加使用：建立一个由「已套用节流机制的DGT网格」在不同间距下组成的集成组合。本文并未测试这一组合方式；这是自然而然的下一步，留待未来研究。"
  )]),

  heading2("C", "动态门槛常数的敏感度"),
  p([run(
    "R_lo=20、R_hi=5,以及公式(3)中的对数空间线性内插形式，都是经过考量后选定的合理整数默认值，而非源自正式统计检定力计算的推导结果。本文并未针对这些常数进行敏感度分析；若要让这项准入准则更加严谨，应该将 R_min(k) 与「作为独立重置事件数量函数的Calmar比率置信区间」明确挂钩，其精神类似最小样本量计算，而非仅凭观察选定的固定端点。"
  )]),

  heading2("D", "单一资产、单一时间窗口的评估"),
  p([run(
    "与 [2] 相同，本文所有结果皆仅使用BTC/USD,且仅涵盖一段历史时期(2021\u20132024)。而这正是第五节E部分所指出的、DMT无法改善MDD的机制性原因所在的那项限制：每一组网格都曝险于同一个底层风险因子，因此集成组合无法分散掉那唯一一次、实际发生的最大回撤事件。一个真正去相关的多重网格集成组合\u2014\u2014例如同时在BTC、ETH及其他若干流动性良好的交易对上运行各组网格，或是将间距分散与 [2] 的节流机制结合\u2014\u2014或许能够实现单靠间距分散所无法达成的时点分散效益；我们目前并未取得品质相当的多资产分钟级数据来测试这一点，留待未来研究。"
  )]),

  heading1("七", "结论"),
  p([run(
    "我们提出了动态多重网格交易(DMT)\u2014\u2014一种由多组各自独立重置、间距各异的DGT实例所组成的集成策略，其动机在于：不同间距的网格对同一段价格历史的反应时点应有所不同，从而使集成组合层级的最大回撤低于任何单一网格。各组网格间的资金分配，已被验证为精确成比例(第三节A部分)，排除了「资金分配错误」作为任何结果的可能解释。我们以3.5年的真实Bitstamp BTC/USD数据检验这项直觉，发现：天真的固定范围集成组合，并未稳健地优于单一挑选得当的网格；而最惊人的表面改善\u2014\u2014宽间距集成组合带来超过12个百分点的MDD降低\u2014\u2014其实是重置次数不足所造成的过度配适假象，与 [2] 针对单一网格参数搜索所记录的病征如出一辙。在引入与间距相关的动态重置次数准入门槛、并据此限制候选网格池之后，我们得到了一项站得住脚的成果：一个三组网格的集成组合，相对已发表的DGT基准，IRR提升3.46个百分点，Calmar比率提升16.9%。然而，最大回撤并未获得改善\u2014\u2014回撤同步性分析(第五节E部分)显示，在集成组合自身表现最差的那一刻，每一组构成网格同时都处于自身历史最深回撤，因此，单靠在单一底层资产上分散间距，并无法实现任何可供兑现的时点分散效益。我们得出结论：同一资产上的多重网格间距分散，是一种适度、真实存在的报酬改善来源，但就其本身而言，并非降低尾部风险的可靠工具；我们建议追求更低回撤的从业者，应将DMT与 [2] 的节流机制结合使用，而非仅依赖间距分散\u2014\u2014本文并未测试这一组合方式，将其标注为未来研究的首要方向。"
  )]),
];

const references = [
  new (require("docx").Paragraph)({
    children: [new (require("docx").TextRun)({ text: "参考文献", font: { ascii: H.FONT, hAnsi: H.FONT, eastAsia: "SimSun" }, size: H.SZ_HEAD1, bold: true })],
    alignment: require("docx").AlignmentType.CENTER, spacing: { before: 220, after: 140 },
  }),
];

function ref(num, text) {
  return p([run(`[${num}]  ${text}`, { size: 18 })], { after: 60, align: require("docx").AlignmentType.LEFT, line: 250 });
}

references.push(
  ref(1, "K.-Y. Chen, K.-H. Chen, and J.-S. R. Jang, \u201cDynamic Grid Trading Strategy: From Zero Expectation to Market Outperformance,\u201d arXiv preprint arXiv:2506.11921, 2025."),
  ref(2, "DGTAP Project, \u201cDynamic Grid Trading with Anti-Martingale Sizing and Protective Options: An Extension Toward Bounded Tail Risk,\u201d unpublished companion technical report, 2026."),
  ref(3, "F. Rundo, F. Trenta, A. L. di Stallo, and S. Battiato, \u201cGrid Trading System Robot (GTSbot): A Novel Mathematical Algorithm for Trading FX Market,\u201d Applied Sciences, vol. 9, no. 9, p. 1796, 2019."),
  ref(4, "F. Rundo, F. Trenta, A. L. di Stallo, and S. Battiato, \u201cAdvanced Markov-Based Machine Learning Framework for Making Adaptive Trading System,\u201d Computation, vol. 7, no. 1, p. 4, 2019."),
  ref(5, "H. E. Leland and M. Rubinstein, \u201cThe Evolution of Portfolio Insurance,\u201d in Portfolio Insurance: A Guide to Dynamic Hedging, D. L. Luskin, Ed. New York: Wiley, 1976."),
  ref(6, "F. Black and R. Jones, \u201cSimplifying Portfolio Insurance,\u201d Journal of Portfolio Management, vol. 14, no. 1, pp. 48\u201351, 1987."),
  ref(7, "F. Black and A. R. Perold, \u201cTheory of Constant Proportion Portfolio Insurance,\u201d Journal of Economic Dynamics and Control, vol. 16, no. 3\u20134, pp. 403\u2013426, 1992."),
  ref(8, "J. L. Kelly Jr., \u201cA New Interpretation of Information Rate,\u201d Bell System Technical Journal, vol. 35, no. 4, pp. 917\u2013926, 1956."),
  ref(9, "M. Avellaneda and S. Stoikov, \u201cHigh-Frequency Trading in a Limit Order Book,\u201d Quantitative Finance, vol. 8, no. 3, pp. 217\u2013224, 2008."),
  ref(10, "D. H. Bailey and M. L\u00f3pez de Prado, \u201cThe Deflated Sharpe Ratio: Correcting for Selection Bias, Backtest Overfitting, and Non-Normality,\u201d Journal of Portfolio Management, vol. 40, no. 5, pp. 94\u2013107, 2014."),
  ref(11, "D. H. Bailey, J. Borwein, M. L\u00f3pez de Prado, and Q. J. Zhu, \u201cThe Probability of Backtest Overfitting,\u201d Journal of Computational Finance, vol. 20, no. 4, pp. 39\u201369, 2017."),
  ref(12, "W. F. Sharpe, \u201cThe Sharpe Ratio,\u201d Journal of Portfolio Management, vol. 21, no. 1, pp. 49\u201358, 1994."),
  ref(13, "M. Magdon-Ismail and A. F. Atiya, \u201cMaximum Drawdown,\u201d Risk Magazine, vol. 17, no. 10, pp. 99\u2013102, 2004."),
  ref(14, "M. Magdon-Ismail, A. F. Atiya, A. Pratap, and Y. S. Abu-Mostafa, \u201cOn the Maximum Drawdown of a Brownian Motion,\u201d Journal of Applied Probability, vol. 41, no. 1, pp. 147\u2013161, 2004."),
  ref(15, "R. Cont, \u201cEmpirical Properties of Asset Returns: Stylized Facts and Statistical Issues,\u201d Quantitative Finance, vol. 1, no. 2, pp. 223\u2013236, 2001."),
  ref(16, "P. Katsiampa, \u201cVolatility Estimation for Bitcoin: A Comparison of GARCH Models,\u201d Economics Letters, vol. 158, pp. 3\u20136, 2017."),
  ref(17, "A. H. Dyhrberg, \u201cHedging Capabilities of Bitcoin. Is It the Virtual Gold?,\u201d Finance Research Letters, vol. 16, pp. 139\u2013144, 2016."),
);

const appendix = [
  new (require("docx").Paragraph)({
    children: [new (require("docx").TextRun)({ text: "附录A\n代码与可重现性", font: { ascii: H.FONT, hAnsi: H.FONT, eastAsia: "SimSun" }, size: H.SZ_HEAD1, bold: true })],
    alignment: require("docx").AlignmentType.CENTER, spacing: { before: 220, after: 140 },
  }),
  p([run(
    "DMT集成组合包装器(DMTMultigrid)以Python实现，针对每一组网格各调用一次 [2] 的DGTStrategy引擎，本金设为 w_i \u00b7 M,并关闭节流机制与认沽期权叠加，再将各组所得的equity_curve序列加总。本文开发的主要脚本包括：(i) 涵盖 grid_size \u00d7 half_n 的完整单一网格参数搜索(对应第五节图1\u20132);(ii) 套用于该搜索结果的动态重置次数门槛筛选器(公式3\u20134);(iii) DMT-3/5/7集成组合的建立，以及与DGT基准及买入并持有的比较(第五节D部分表格);以及(iv) 回撤同步性诊断工具(公式8,第五节E部分)。本文核心的DMT-3配置为 {(k=2.5%, m=6), (k=3.5%, m=6), (k=5.0%, m=6)},各组等权重1/3,本金100,手续费8个基点，关闭节流机制与认沽期权叠加。所有回测均沿用 [2] 所附Bitstamp BTC/USD一分钟数据集(2021-01-01至2024-07-31)及其随附的DGTStrategy引擎；本文并未为此额外收集新的市场数据。",
    { size: 18 })], { line: 250 }),
];

module.exports = { section6_discussion, references, appendix };
