const H = require("./helpers");
const { AlignmentType, p, run, heading1, heading2, eqBlock, makeTable } = H;
const EQ = "eqs/";

const section3_method = [
  heading1("III", "DMT: Proposed Extension"),

  heading2("A", "Ensemble Construction"),
  p([run(
    "DMT runs N independent DGT engines in parallel, indexed i = 1..N, each configured with its own grid spacing k_i and half-width m_i, exactly as specified in [1] and re-implemented faithfully in [2] (proportional 1/G_i, 1/G_j fills; asymmetric reset \u2014 liquidate-to-cash on an upward breach, hold-and-fund-from-profit on a downward breach). Total capital M is split across legs by fixed weight w_i:"
  )]),
  eqBlock(EQ + "eq2_leg_capital.png", 80, 18, 1),
  p([run("Each leg is then run to completion independently, and the ensemble's mark-to-market equity is the sum of leg equities:")]),
  eqBlock(EQ + "eq1_ensemble.png", 220, 38, 2),
  p([run(
    "Because each DGTStrategy engine is purely fraction-based (every fill is a fixed fraction of that engine's own current wallet), leg-level performance is exactly scale-invariant: running a leg at capital w_i\u00b7M produces trade counts, reset counts, and percentage returns identical to running it at full capital M, with the dollar-denominated equity path scaled by exactly w_i. We verified this numerically prior to any ensemble backtest (Section V-D confirms combined capital sums to M to floating-point precision), which rules out capital-misallocation as an explanation for any of the results below and isolates the analysis to the effect of combining different k_i, m_i alone."
  )]),

  heading2("B", "The Reset-Count Significance Problem"),
  p([run(
    "A grid that almost never reaches its boundary behaves, for practical purposes, like a static basket that happens to have been wide enough to contain the entire realized price path \u2014 its favorable backtest statistics reflect the width of the historical price range as much as any property of the trading rule. This is precisely the pathology documented for single grids in [2, Sec. V-B]. At the ensemble level the same pathology is easy to reintroduce inadvertently: an ensemble containing one or more wide, rarely-resetting legs can show a large apparent MDD improvement that is really just averaging in a leg that is, statistically, closer to a single lucky bet on the price staying inside a band than to a validated trading rule. Section V-B documents this concretely: an ensemble curated by picking the highest-Calmar single-grid configurations available in a 10\u201330% spacing range improves MDD by over 12 percentage points \u2014 but every contributing leg resets 0\u20132 times over the full 3.5-year window."
  )]),

  heading2("C", "A Spacing-Dependent Dynamic Reset-Count Threshold"),
  p([run(
    "A fixed reset-count floor (e.g., the resets\u226540 rule used for single grids in [2]) is a reasonable safeguard for grids of a given spacing but is not spacing-neutral: narrow grids are structurally expected to reset often, while wide grids are structurally expected to reset rarely even when they are behaving exactly as intended, so a single global floor either admits too many narrow, low-quality legs or excludes every wide leg outright. We instead define a minimum reset count that varies with spacing, interpolating log-linearly between a stricter floor R_lo for the narrowest admissible spacing k_min and a looser floor R_hi for the widest admissible spacing k_max observed in the search:"
  )]),
  eqBlock(EQ + "eq3_dynthresh.png", 255, 26, 3),
  p([run(
    "A candidate leg with spacing k_i and observed reset count resets_i is admissible into the DMT pool if and only if"
  )]),
  eqBlock(EQ + "eq4_admissible.png", 184, 19, 4),
  p([run(
    "In all experiments below we use R_lo = 20, R_hi = 5, with k_min and k_max taken as the smallest and largest spacings in the full single-grid sweep (0.8% and 30% respectively; Fig. 2). These constants are a design choice, not a first-principles derivation; Section VI-C discusses this limitation."
  )]),

  heading2("D", "Evaluation Metrics"),
  p([run("Standard performance statistics in this literature include the Sharpe ratio [12], maximum drawdown [13], [14], and the Calmar ratio (IRR divided by |MDD|). Consistent with [1] and [2], this paper reports IRR, MDD, and Calmar throughout (we do not compute a Sharpe ratio, since minute-resolution returns for a discretely-triggered strategy are not well approximated by its normality assumption):")]),
  eqBlock(EQ + "eq5_irr.png", 99, 26, 5),
  eqBlock(EQ + "eq6_mdd.png", 114, 36, 6),
  eqBlock(EQ + "eq7_calmar.png", 83, 23, 7),

  heading2("E", "Drawdown Synchronization Index"),
  p([run(
    "To directly test whether an ensemble's drawdown improvement (or lack thereof) is attributable to decorrelated leg timing, we define a synchronization index evaluated at t*, the timestamp of the ensemble's own maximum drawdown:"
  )]),
  eqBlock(EQ + "eq8_syncindex.png", 330, 38, 8),
  p([run(
    "SI = 1 means every leg is simultaneously at (or within \u03b5 of) its own individual worst historical drawdown at the exact moment the ensemble is at its worst \u2014 i.e., zero timing diversification benefit was realized. SI = 0 would mean no leg is near its own worst at that moment \u2014 maximal timing diversification. We use \u03b5 = 0 (exact equality, to floating-point precision) in Section V-E, which turns out to be achievable because the identical trades and resets are deterministic given the shared price path."
  )]),
];

const section4_data = [
  heading1("IV", "Data and Experimental Setup"),
  p([run(
    "All results use the same real, exchange-sourced dataset as [2]: Bitstamp BTC/USD, one-minute resolution, January 1, 2021 through July 31, 2024 (1,882,081 bars), reused directly from the reproducibility package accompanying [2] so that the DGT baseline figures reported here are the identical numbers reported there (verified to match to two decimal places prior to any DMT-specific analysis)."
  )]),
  p([run(
    "A round-trip taker fee of 8 bps (0.0008) is applied to every grid fill. Initial capital is normalized to 100 units. Every DMT leg and every single-grid comparison in this paper is run with the anti-martingale throttle and put overlay of [2] disabled, isolating the effect under study to ensemble spacing alone; none of the results below should be interpreted as showing DMT is superior or inferior to DGTAP \u2014 the two extensions modify different, non-exclusive parts of the DGT mechanism, a point returned to in Section VI-B."
  )]),
];

module.exports = { section3_method, section4_data };
