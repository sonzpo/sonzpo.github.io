const H = require("./helpers");
const {
  Document, Packer, Paragraph, TextRun, AlignmentType, SectionType,
  Header, Footer, PageNumber, convertInchesToTwip,
  p, run, heading1, heading2, caption, figureImage, eqBlock, makeTable, img,
} = H;

const EQ = "eqs/", FIG = "figs/";

// ---------------------------------------------------------------------
// Title block
// ---------------------------------------------------------------------
const titleBlock = [
  new Paragraph({
    children: [run("Dynamic Multigrid Trading: A Reset-Count-Constrained Ensemble Extension of Dynamic Grid Trading",
      { size: H.SZ_TITLE, bold: true })],
    alignment: AlignmentType.CENTER, spacing: { after: 160 },
  }),
  new Paragraph({
    children: [run("[Author name(s) to be filled in]", { size: H.SZ_AUTHOR })],
    alignment: AlignmentType.CENTER, spacing: { after: 20 },
  }),
  new Paragraph({
    children: [run("[Affiliation to be filled in]", { size: H.SZ_AUTHOR, italics: true })],
    alignment: AlignmentType.CENTER, spacing: { after: 20 },
  }),
  new Paragraph({
    children: [run("July 2026", { size: H.SZ_AUTHOR })],
    alignment: AlignmentType.CENTER, spacing: { after: 200 },
  }),
  p([run(
    "Note on provenance: This paper extends the dynamic-reset grid trading framework (\u201cDGT\u201d) introduced by Chen, Chen, and Jang [1], and is a sibling extension to the anti-martingale/protective-put framework (\u201cDGTAP\u201d) developed in a companion report [2]. The multigrid ensemble construction, the reset-count admissibility criterion, and all backtest results in Sections V\u2013VI are original to this paper and were produced on the same real-market dataset used in [2] for direct comparability.",
    { size: H.SZ_ABSTRACT, italics: true })], { after: 160 }),
];

// ---------------------------------------------------------------------
// Abstract + Index Terms
// ---------------------------------------------------------------------
const abstractBlock = [
  p([
    run("Abstract\u2014", { size: H.SZ_ABSTRACT, bold: true, italics: true }),
    run(
      "Dynamic Grid Trading (DGT) breaks the zero-expectation result of naive grid trading by re-centering the grid on breach rather than terminating, but a single grid spacing forces a compromise between capturing range-bound oscillation and capturing large directional moves. We propose Dynamic Multigrid Trading (DMT), an ensemble of independently-reset DGT instances run in parallel at different geometric spacings k_i, with total capital split by fixed weight w_i across legs. We show, on 3.5 years of real Bitstamp BTC/USD 1-minute data (the same dataset used in [2]), that (i) naive equal-weight ensembles spanning arbitrary spacing ranges are not robustly better than a single well-chosen grid; (ii) wide-spacing ensembles that appear to cut maximum drawdown (MDD) by over 12 percentage points do so only because the legs trigger too few reset events to be statistically meaningful \u2014 the same overfitting failure mode documented for grid-parameter search in [2, Sec. V-B], now surfacing at the ensemble level; and (iii) after introducing a spacing-dependent dynamic reset-count admissibility threshold and restricting the leg pool accordingly, a 3-leg ensemble ({2.5%, 3.5%, 5.0%}, m=6, equal weight) improves annualized return (IRR) by 3.46 percentage points and the Calmar ratio by 16.9% relative to the published DGT baseline, while MDD remains essentially unchanged (\u22120.10 pp). We trace this last result to near-perfect drawdown-timing synchronization across differently-spaced grids on the same underlying asset: at the ensemble's own worst moment (the June 2022 Terra/3AC crash), all three legs are simultaneously at their own all-time-worst drawdown. We conclude that same-asset spacing diversification is a modest, statistically defensible source of return and risk-adjusted-return improvement, but is not, by itself, a reliable lever for reducing tail risk \u2014 for which the throttle/option mechanisms of [2] remain better targeted.",
      { size: H.SZ_ABSTRACT }),
  ], { after: 100 }),
  p([
    run("Index Terms\u2014", { size: H.SZ_ABSTRACT, bold: true, italics: true }),
    run("algorithmic trading, grid trading, ensemble methods, cryptocurrency, backtest overfitting, drawdown, Bitcoin, dynamic grid trading.", { size: H.SZ_ABSTRACT }),
  ], { after: 160 }),
];

module.exports = { titleBlock, abstractBlock, EQ, FIG };
